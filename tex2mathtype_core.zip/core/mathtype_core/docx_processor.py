from typing import Callable
import os
import re
import shutil
import zipfile
from lxml import etree
import uuid
try:
    from .latex_to_mathtype import ConvertedEquation, LaTeXToMathTypeConverter
except (ImportError, ValueError):
    from latex_to_mathtype import ConvertedEquation, LaTeXToMathTypeConverter

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
V_NS = "urn:schemas-microsoft-com:vml"
O_NS = "urn:schemas-microsoft-com:office:office"
W14_NS = "http://schemas.microsoft.com/office/word/2010/wordml"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"

SHAPETYPE_XML = (
    f'<v:shapetype xmlns:v="{V_NS}" xmlns:o="{O_NS}" id="_x0000_t75" '
    'coordsize="21600,21600" o:spt="75" o:preferrelative="t" '
    'path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">'
    '<v:stroke joinstyle="miter"/>'
    "<v:formulas>"
    '<v:f eqn="if lineDrawn pixelLineWidth 0"/>'
    '<v:f eqn="sum @0 1 0"/>'
    '<v:f eqn="sum 0 0 @1"/>'
    '<v:f eqn="prod @2 1 2"/>'
    '<v:f eqn="prod @3 21600 pixelWidth"/>'
    '<v:f eqn="prod @3 21600 pixelHeight"/>'
    '<v:f eqn="sum @0 0 1"/>'
    '<v:f eqn="prod @6 1 2"/>'
    '<v:f eqn="prod @7 21600 pixelWidth"/>'
    '<v:f eqn="sum @8 21600 0"/>'
    '<v:f eqn="prod @7 21600 pixelHeight"/>'
    '<v:f eqn="sum @10 21600 0"/>'
    "</v:formulas>"
    '<v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>'
    '<o:lock v:ext="edit" aspectratio="t"/>'
    "</v:shapetype>"
)

# Regex matching $$...$$, \[...\], \(...\), or $...$ (an toàn với \$ thoát và không bắt nhầm $$ rỗng)
MATH_PATTERN = re.compile(r"(\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|(?<!\$)\$(?!\$)(?:\\\$|[^\$])+?(?<!\\)(?<!\$)\$(?!\$))")


def _find_unescaped_close_dollar(text: str, start: int) -> int:
    n = len(text)
    i = start
    env_depth = 0
    while i < n:
        ch = text[i]
        if ch == "\n":
            return -1
        if text[i : i + 2] == r"\\":
            if env_depth == 0:
                return -1
            i += 2
            continue
        if ch == "\\":
            if text[i : i + 2] == r"\$":
                i += 2
                continue
            if text.startswith(r"\begin{", i) or re.match(r"\\begin\s*\{", text[i:]):
                env_depth += 1
            elif (text.startswith(r"\end{", i) or re.match(r"\\end\s*\{", text[i:])) and env_depth > 0:
                env_depth -= 1
            i += 1
            continue
        if ch == "$":
            return i
        i += 1
    return -1


def _find_escaped_pair(text: str, start: int, close_tok: str) -> int:
    n = len(text)
    i = start
    while i < n:
        if text[i : i + 2] == r"\\":
            i += 2
            continue
        if text[i : i + 2] == close_tok:
            return i
        i += 1
    return -1


def split_math_segments(text: str) -> list[str]:
    """Split text into alternating plain/math tokens without regex lookbehind failures on $a$$b$."""
    parts: list[str] = []
    n = len(text)
    i = 0
    buf_start = 0

    def _flush_plain(end_idx: int):
        if end_idx > buf_start:
            parts.append(text[buf_start:end_idx])

    while i < n:
        ch = text[i]
        if ch == "\\":
            nxt2 = text[i : i + 2]
            if nxt2 in (r"\\", r"\$"):
                i += 2
                continue
            if nxt2 in (r"\[", r"\("):
                close_tok = r"\]" if nxt2 == r"\[" else r"\)"
                end_pos = _find_escaped_pair(text, i + 2, close_tok)
                if end_pos != -1 and text[i + 2 : end_pos].strip():
                    _flush_plain(i)
                    parts.append(text[i : end_pos + 2])
                    i = end_pos + 2
                    buf_start = i
                    continue
            i += 1
            continue

        if ch == "$":
            if i + 1 < n and text[i + 1] == "$":
                end_pos = text.find("$$", i + 2)
                if end_pos != -1 and text[i + 2 : end_pos].strip():
                    _flush_plain(i)
                    parts.append(text[i : end_pos + 2])
                    i = end_pos + 2
                    buf_start = i
                    continue
                i += 2
                continue
            end_pos = _find_unescaped_close_dollar(text, i + 1)
            if end_pos != -1:
                inner = text[i + 1 : end_pos]
                _flush_plain(i)
                if inner.strip():
                    parts.append(text[i : end_pos + 1])
                elif inner:
                    parts.append(inner)
                i = end_pos + 1
                buf_start = i
                continue
        i += 1

    _flush_plain(n)
    return parts


def is_math_segment(seg: str) -> bool:
    if not seg:
        return False
    if len(seg) >= 4 and seg.startswith("$$") and seg.endswith("$$"):
        return bool(seg[2:-2].strip())
    if len(seg) >= 4 and (
        (seg.startswith(r"\[") and seg.endswith(r"\]"))
        or (seg.startswith(r"\(") and seg.endswith(r"\)"))
    ):
        return bool(seg[2:-2].strip())
    if len(seg) >= 2 and seg.startswith("$") and seg.endswith("$") and not seg.startswith("$$"):
        return bool(seg[1:-1].strip())
    return False


class DocxMathTypeProcessor:
    def __init__(self, converter: LaTeXToMathTypeConverter | None = None, base_pt: float = 11.0):
        self.converter = converter or LaTeXToMathTypeConverter(base_pt=base_pt)

    def process_file(
        self,
        input_path: str,
        output_path: str | None = None,
        convert_math: bool = True,
        process_imath: bool = False,
        normalize_true: bool = False,
        progress_cb: Callable[[int, int, str], None] | None = None,
    ) -> tuple[str, int]:
        """
        Process a .docx file and return (output_path, converted_formula_count).
        """
        if output_path is None:
            base, ext = os.path.splitext(input_path)
            if base.endswith("_mathtype"):
                output_path = base + "_out" + ext
            else:
                output_path = base + "_mathtype" + ext

        is_same = (os.path.abspath(input_path) == os.path.abspath(output_path))
        target_output = (
            output_path + f".tmp_{uuid.uuid4().hex[:6]}.docx"
            if is_same
            else output_path
        )

        with zipfile.ZipFile(input_path, "r") as zin:
            namelist = zin.namelist()
            file_map = {name: zin.read(name) for name in namelist}

        # Parse word/document.xml
        doc_xml_bytes = file_map["word/document.xml"]
        parser = etree.XMLParser(remove_blank_text=False, huge_tree=True)
        doc_root = etree.fromstring(doc_xml_bytes, parser)

        # Ensure v: and o: namespaces are present on root via dummy attribute if needed
        self._ensure_namespaces(doc_root)

        # Optional Step 1: Process iMath exam structure & \True normalization on paragraphs
        if process_imath or normalize_true:
            self._transform_imath_paragraphs(doc_root, process_imath=process_imath, normalize_true=normalize_true)

        # Step 2: Convert $...$ formulas to clickable MathType Equation.DSMT4 OLE objects
        total_converted = 0
        new_media: dict[str, bytes] = {}
        new_embeddings: dict[str, bytes] = {}
        new_rels: list[tuple[str, str, str]] = []

        if convert_math:
            rels_xml_bytes = file_map["word/_rels/document.xml.rels"]
            rels_root = etree.fromstring(rels_xml_bytes, parser)
            max_rid = self._get_max_rid(rels_root)
            max_img_idx = self._get_max_numbered_file(namelist, "word/media/image", ".wmf")
            max_ole_idx = self._get_max_numbered_file(namelist, "word/embeddings/oleObject", ".bin")

            paragraphs = doc_root.findall(f".//{{{W_NS}}}p")
            # Pre-count formulas for accurate progress reporting
            all_formulas = []
            for p in paragraphs:
                ptime_text = "".join(t.text or "" for t in p.findall(f".//{{{W_NS}}}t"))
                if "$" in ptime_text or r"\[" in ptime_text or r"\(" in ptime_text:
                    matches = [seg for seg in split_math_segments(ptime_text) if is_math_segment(seg)]
                    if matches:
                        all_formulas.extend(matches)

            total_formulas = len(all_formulas)
            wmf_rid_cache: dict[str, str] = {}
            shapetype_emitted = False
            shape_counter = 1025
            obj_id_base = 1853387800

            for p in paragraphs:
                p_text = "".join(t.text or "" for t in p.findall(f".//{{{W_NS}}}t"))
                if "$" not in p_text and r"\[" not in p_text and r"\(" not in p_text:
                    continue
                if not any(is_math_segment(seg) for seg in split_math_segments(p_text)):
                    continue

                converted_in_p, max_rid, max_img_idx, max_ole_idx, shape_counter, shapetype_emitted = (
                    self._convert_paragraph_math(
                        p=p,
                        max_rid=max_rid,
                        max_img_idx=max_img_idx,
                        max_ole_idx=max_ole_idx,
                        shape_counter=shape_counter,
                        obj_id_base=obj_id_base,
                        shapetype_emitted=shapetype_emitted,
                        wmf_rid_cache=wmf_rid_cache,
                        new_media=new_media,
                        new_embeddings=new_embeddings,
                        new_rels=new_rels,
                        total_converted_so_far=total_converted,
                        total_formulas=total_formulas,
                        progress_cb=progress_cb,
                    )
                )
                total_converted += converted_in_p

            # Update word/_rels/document.xml.rels
            for rid, rel_type, target in new_rels:
                rel_el = etree.SubElement(rels_root, f"{{{PKG_REL_NS}}}Relationship")
                rel_el.set("Id", rid)
                rel_el.set("Type", rel_type)
                rel_el.set("Target", target)
            file_map["word/_rels/document.xml.rels"] = etree.tostring(
                rels_root, xml_declaration=True, encoding="UTF-8", standalone="yes"
            )

            # Update [Content_Types].xml
            ct_root = etree.fromstring(file_map["[Content_Types].xml"], parser)
            self._ensure_content_types(ct_root)
            file_map["[Content_Types].xml"] = etree.tostring(
                ct_root, xml_declaration=True, encoding="UTF-8", standalone="yes"
            )

        # Serialize updated word/document.xml
        file_map["word/document.xml"] = etree.tostring(
            doc_root, xml_declaration=True, encoding="UTF-8", standalone="yes"
        )

        # Add new media and embeddings
        for mpath, mbytes in new_media.items():
            file_map[mpath] = mbytes
        for epath, ebytes in new_embeddings.items():
            file_map[epath] = ebytes

        # Write output .docx
        with zipfile.ZipFile(target_output, "w", compression=zipfile.ZIP_DEFLATED) as zout:
            for name, content in file_map.items():
                zout.writestr(name, content)

        if is_same:
            shutil.move(target_output, output_path)

        if progress_cb:
            progress_cb(total_converted, max(1, total_converted), "Hoàn tất!")

        return output_path, total_converted

    def _ensure_namespaces(self, doc_root: etree._Element):
        # Ensure v and o namespaces are available when serializing
        nsmap = doc_root.nsmap
        if "v" not in nsmap or "o" not in nsmap:
            xml_str = etree.tostring(doc_root, encoding="unicode")
            if 'xmlns:v="' not in xml_str:
                xml_str = xml_str.replace(
                    "<w:document ",
                    f'<w:document xmlns:v="{V_NS}" xmlns:o="{O_NS}" xmlns:r="{R_NS}" ',
                    1,
                )
                new_root = etree.fromstring(xml_str.encode("utf-8"))
                doc_root[:] = new_root[:]
                for k, v in new_root.attrib.items():
                    doc_root.set(k, v)

    @staticmethod
    def _get_max_rid(rels_root: etree._Element) -> int:
        max_id = 0
        for el in rels_root:
            rid = el.get("Id", "")
            if rid.startswith("rId") and rid[3:].isdigit():
                max_id = max(max_id, int(rid[3:]))
        return max_id

    @staticmethod
    def _get_max_numbered_file(namelist: list[str], prefix: str, suffix: str) -> int:
        max_idx = 0
        for name in namelist:
            if name.startswith(prefix) and name.endswith(suffix):
                mid = name[len(prefix) : -len(suffix)]
                if mid.isdigit():
                    max_idx = max(max_idx, int(mid))
        return max_idx

    @staticmethod
    def _ensure_content_types(ct_root: etree._Element):
        existing_exts = {
            el.get("Extension", "").lower() for el in ct_root.findall(f"{{{CT_NS}}}Default")
        }
        if "wmf" not in existing_exts:
            el = etree.Element(f"{{{CT_NS}}}Default")
            el.set("Extension", "wmf")
            el.set("ContentType", "image/x-wmf")
            ct_root.insert(0, el)
        if "bin" not in existing_exts:
            el = etree.Element(f"{{{CT_NS}}}Default")
            el.set("Extension", "bin")
            el.set("ContentType", "application/vnd.openxmlformats-officedocument.oleObject")
            ct_root.insert(0, el)

    def _convert_paragraph_math(
        self,
        p: etree._Element,
        max_rid: int,
        max_img_idx: int,
        max_ole_idx: int,
        shape_counter: int,
        obj_id_base: int,
        shapetype_emitted: bool,
        wmf_rid_cache: dict[str, str],
        new_media: dict[str, bytes],
        new_embeddings: dict[str, bytes],
        new_rels: list[tuple[str, str, str]],
        total_converted_so_far: int,
        total_formulas: int,
        progress_cb: Callable[[int, int, str], None] | None,
    ):
        """
        Consolidate contiguous text runs in paragraph `p`, split by MATH_PATTERN,
        and replace each math formula with a clickable MathType Equation.DSMT4 <w:r> element.
        """
        children = list(p)
        converted_here = 0

        # Group contiguous <w:r> elements that only contain <w:rPr> and <w:t>
        i = 0
        n = len(children)
        new_children = []

        while i < n:
            ch = children[i]
            if ch.tag != f"{{{W_NS}}}r" or not self._is_plain_text_run(ch):
                new_children.append(ch)
                i += 1
                continue

            # Collect contiguous plain text runs
            run_group = [ch]
            j = i + 1
            while j < n and children[j].tag == f"{{{W_NS}}}r" and self._is_plain_text_run(children[j]):
                run_group.append(children[j])
                j += 1

            group_text = "".join(self._get_run_text(r) for r in run_group)
            if not any(is_math_segment(seg) for seg in split_math_segments(group_text)):
                new_children.extend(run_group)
                i = j
                continue

            # Check if any run in run_group has lastRenderedPageBreak
            has_page_break = any(
                r.find(f"{{{W_NS}}}lastRenderedPageBreak") is not None for r in run_group
            )

            # Preserve character map of original rPr per character index so bold/underline/color on text is kept!
            char_rprs = []
            for r in run_group:
                rpr = r.find(f"{{{W_NS}}}rPr")
                rtxt = self._get_run_text(r)
                for _ in rtxt:
                    char_rprs.append(rpr)

            parts = split_math_segments(group_text)
            char_cursor = 0
            group_children = []

            for part in parts:
                if not part:
                    continue
                part_len = len(part)
                if is_math_segment(part):
                    eq = self.converter.convert(part)
                    norm_key = eq.mtef_bytes.hex()

                    # 1. Get or create WMF relationship (deduplicated per unique formula!)
                    if norm_key in wmf_rid_cache:
                        wmf_rid = wmf_rid_cache[norm_key]
                    else:
                        max_img_idx += 1
                        max_rid += 1
                        wmf_rid = f"rId{max_rid}"
                        wmf_target = f"media/image{max_img_idx}.wmf"
                        new_media[f"word/{wmf_target}"] = eq.wmf_bytes
                        new_rels.append(
                            (
                                wmf_rid,
                                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                                wmf_target,
                            )
                        )
                        wmf_rid_cache[norm_key] = wmf_rid

                    # 2. Create OLE embedding relationship for this occurrence
                    max_ole_idx += 1
                    max_rid += 1
                    ole_rid = f"rId{max_rid}"
                    ole_target = f"embeddings/oleObject{max_ole_idx}.bin"
                    new_embeddings[f"word/{ole_target}"] = eq.ole_bytes
                    new_rels.append(
                        (
                            ole_rid,
                            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/oleObject",
                            ole_target,
                        )
                    )

                    # 3. Build <w:r> containing <w:object>
                    shape_id = f"_x0000_i{shape_counter}"
                    object_id = f"_{obj_id_base + max_ole_idx - 1}"
                    shape_counter += 1

                    eq_run = self._build_equation_run_element(
                        eq=eq,
                        wmf_rid=wmf_rid,
                        ole_rid=ole_rid,
                        shape_id=shape_id,
                        object_id=object_id,
                        include_shapetype=not shapetype_emitted,
                    )
                    shapetype_emitted = True
                    group_children.append(eq_run)
                    converted_here += 1

                    if progress_cb and (total_converted_so_far + converted_here) % 10 == 0:
                        progress_cb(
                            total_converted_so_far + converted_here,
                            max(1, total_formulas),
                            f"Đã chuyển {total_converted_so_far + converted_here}/{total_formulas} công thức...",
                        )
                else:
                    # Emit text runs grouped by identical rPr reference
                    seg_start = 0
                    while seg_start < part_len:
                        rpr_ref = (
                            char_rprs[char_cursor + seg_start]
                            if (char_cursor + seg_start) < len(char_rprs)
                            else None
                        )
                        seg_end = seg_start + 1
                        while (
                            seg_end < part_len
                            and (char_cursor + seg_end) < len(char_rprs)
                            and char_rprs[char_cursor + seg_end] is rpr_ref
                        ):
                            seg_end += 1
                        sub_txt = part[seg_start:seg_end]
                        group_children.append(self._build_text_run(sub_txt, rpr_ref))
                        seg_start = seg_end

                char_cursor += part_len

            if has_page_break and group_children:
                first_r = group_children[0]
                if first_r.tag == f"{{{W_NS}}}r" and first_r.find(f"{{{W_NS}}}object") is None:
                    t_idx = 0
                    for idx_c, c_el in enumerate(first_r):
                        if c_el.tag == f"{{{W_NS}}}t":
                            t_idx = idx_c
                            break
                    first_r.insert(t_idx, etree.Element(f"{{{W_NS}}}lastRenderedPageBreak"))
                else:
                    pb_run = etree.Element(f"{{{W_NS}}}r")
                    etree.SubElement(pb_run, f"{{{W_NS}}}lastRenderedPageBreak")
                    group_children.insert(0, pb_run)

            new_children.extend(group_children)
            i = j

        # Replace children of paragraph p
        p[:] = new_children
        return converted_here, max_rid, max_img_idx, max_ole_idx, shape_counter, shapetype_emitted

    @staticmethod
    def _is_plain_text_run(r: etree._Element) -> bool:
        for child in r:
            tag = child.tag
            if tag in (
                f"{{{W_NS}}}object",
                f"{{{W_NS}}}drawing",
                f"{{{W_NS}}}pict",
                f"{{{W_NS}}}fldChar",
                f"{{{W_NS}}}ruby",
                f"{{{W_NS}}}br",
                f"{{{W_NS}}}tab",
            ):
                return False
        return True

    @staticmethod
    def _get_run_text(r: etree._Element) -> str:
        parts = []
        for child in r:
            if child.tag == f"{{{W_NS}}}t":
                parts.append(child.text or "")
            elif child.tag == f"{{{W_NS}}}tab":
                parts.append("\t")
        return "".join(parts)

    @staticmethod
    def _build_text_run(text: str, rpr_template: etree._Element | None) -> etree._Element:
        r = etree.Element(f"{{{W_NS}}}r")
        if rpr_template is not None:
            r.append(etree.fromstring(etree.tostring(rpr_template)))
        if "\t" in text:
            pieces = text.split("\t")
            for idx, piece in enumerate(pieces):
                if idx > 0:
                    etree.SubElement(r, f"{{{W_NS}}}tab")
                if piece:
                    t = etree.SubElement(r, f"{{{W_NS}}}t")
                    if piece.startswith(" ") or piece.endswith(" ") or "  " in piece:
                        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                    t.text = piece
        else:
            t = etree.SubElement(r, f"{{{W_NS}}}t")
            if text.startswith(" ") or text.endswith(" ") or "  " in text:
                t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            t.text = text
        return r

    @staticmethod
    def _build_equation_run_element(
        eq: ConvertedEquation,
        wmf_rid: str,
        ole_rid: str,
        shape_id: str,
        object_id: str,
        include_shapetype: bool,
    ) -> etree._Element:
        shapetype_part = SHAPETYPE_XML if include_shapetype else ""
        w_str = f"{eq.width_pt:.2f}".rstrip("0").rstrip(".")
        h_str = f"{eq.height_pt:.2f}".rstrip("0").rstrip(".")
        run_xml = (
            f'<w:r xmlns:w="{W_NS}" xmlns:r="{R_NS}" xmlns:v="{V_NS}" xmlns:o="{O_NS}">'
            "<w:rPr>"
            '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
            '<w:color w:val="000000"/>'
            f'<w:position w:val="{eq.pos_half_pts}"/>'
            '<w:sz w:val="24"/>'
            "</w:rPr>"
            f'<w:object w:dxaOrig="{eq.dxa_orig}" w:dyaOrig="{eq.dya_orig}">'
            f"{shapetype_part}"
            f'<v:shape id="{shape_id}" type="#_x0000_t75" style="width:{w_str}pt;height:{h_str}pt" o:ole="">'
            f'<v:imagedata r:id="{wmf_rid}" o:title=""/>'
            "</v:shape>"
            f'<o:OLEObject Type="Embed" ProgID="Equation.DSMT4" ShapeID="{shape_id}" '
            f'DrawAspect="Content" ObjectID="{object_id}" r:id="{ole_rid}"/>'
            "</w:object>"
            "</w:r>"
        )
        return etree.fromstring(run_xml.encode("utf-8"))

    # =========================================================================
    # iMath Question Standardization & \True Answer Normalization
    # =========================================================================
    def _transform_imath_paragraphs(
        self, doc_root: etree._Element, process_imath: bool, normalize_true: bool
    ):
        body = doc_root.find(f"{{{W_NS}}}body")
        if body is None:
            return

        if not process_imath and normalize_true:
            # Only normalize \True in existing paragraphs without restructuring iMath blocks
            for p in body.findall(f".//{{{W_NS}}}p"):
                txt = "".join(t.text or "" for t in p.findall(f".//{{{W_NS}}}t"))
                if r"\True" in txt:
                    cleaned = re.sub(r"\\True\s*", "", txt)
                    self._set_paragraph_runs(
                        p,
                        [
                            ("✓ ", True, True),
                            (cleaned, False, False),
                        ],
                    )
            return

        # Full iMath (\begin{ex}...\end{ex}) processing
        paragraphs = list(body.findall(f"{{{W_NS}}}p"))
        raw_lines = ["".join(t.text or "" for t in p.findall(f".//{{{W_NS}}}t")) for p in paragraphs]
        full_text = "\n".join(raw_lines)

        if r"\begin{ex}" not in full_text and r"\begin{bt}" not in full_text and r"\begin{vd}" not in full_text:
            if normalize_true:
                for p in paragraphs:
                    txt = "".join(t.text or "" for t in p.findall(f".//{{{W_NS}}}t"))
                    if r"\True" in txt:
                        cleaned = re.sub(r"\\True\s*", "", txt)
                        self._set_paragraph_runs(p, [(cleaned, True, True)])
            return

        # Parse full_text into structured output paragraphs: list of list[(text, bold, underline)]
        out_paras = self._parse_imath_document(full_text, normalize_true=normalize_true)

        # Preserve sectPr at end of body
        sect_pr = body.find(f"{{{W_NS}}}sectPr")
        for p in paragraphs:
            body.remove(p)

        for runs_spec in out_paras:
            new_p = etree.Element(f"{{{W_NS}}}p")
            self._set_paragraph_runs(new_p, runs_spec)
            if sect_pr is not None:
                body.insert(body.index(sect_pr), new_p)
            else:
                body.append(new_p)

    def _parse_imath_document(
        self, full_text: str, normalize_true: bool
    ) -> list[list[tuple[str, bool, bool]]]:
        # Remove %% comment lines
        lines = []
        for ln in full_text.splitlines():
            s = ln.strip()
            if s.startswith("%%"):
                continue
            # Remove \chapter{...} / \section{...} wrappers into bold headings
            m_chap = re.match(r"^\\(?:chapter|section|subsection)\{(.+)\}$", s)
            if m_chap:
                lines.append(f"__HEADING__:{m_chap.group(1)}")
                continue
            lines.append(ln)

        joined = "\n".join(lines)
        out_paras: list[list[tuple[str, bool, bool]]] = []

        # Split by \begin{ex} ... \end{ex}
        ex_pattern = re.compile(r"\\begin\{(ex|bt|vd)\}([\s\S]*?)\\end\{\1\}")
        pos = 0
        q_num = 1
        for m in ex_pattern.finditer(joined):
            before = joined[pos : m.start()].strip()
            if before:
                for bln in before.splitlines():
                    bln = bln.strip()
                    if bln.startswith("__HEADING__:"):
                        out_paras.append([(bln[12:], True, False)])
                    elif bln:
                        out_paras.append([(bln, False, False)])

            block = m.group(2)
            block_paras = self._format_single_ex_block(block, q_num, normalize_true=normalize_true)
            out_paras.extend(block_paras)
            q_num += 1
            pos = m.end()

        after = joined[pos:].strip()
        if after:
            for aln in after.splitlines():
                aln = aln.strip()
                if aln.startswith("__HEADING__:"):
                    out_paras.append([(aln[12:], True, False)])
                elif aln:
                    out_paras.append([(aln, False, False)])

        return out_paras

    def _format_single_ex_block(
        self, block: str, q_num: int, normalize_true: bool
    ) -> list[list[tuple[str, bool, bool]]]:
        # Strip %[...] metadata comments
        block = re.sub(r"%\[[^\]]*\]", "", block)
        # Strip \begin{tikzpicture}...\end{tikzpicture}
        block = re.sub(r"\\begin\{tikzpicture\}[\s\S]*?\\end\{tikzpicture\}", "", block)

        # Unwrap \immini[...]{stem}{fig} or \immini{stem}{fig}
        block = self._unwrap_macro(block, "immini", keep_arg_idx=0)

        # Extract \loigiai{...} if present
        loigiai_text = None
        lg_idx = block.find(r"\loigiai")
        if lg_idx >= 0:
            args, end_pos = self._extract_brace_args(block, lg_idx + len(r"\loigiai"), max_args=1)
            if args:
                loigiai_text = args[0].strip()
                block = block[:lg_idx] + block[end_pos:]

        # Check for \choice, \choiceTF, \shortans
        choices = []
        choice_mode = None  # "ABCD", "TF", "SHORT"

        for cmd, mode, nargs in [
            (r"\choiceTF", "TF", 4),
            (r"\choicefix", "ABCD", 4),
            (r"\choice", "ABCD", 4),
            (r"\motcot", "ABCD", 4),
            (r"\haicot", "ABCD", 4),
            (r"\boncot", "ABCD", 4),
            (r"\shortans", "SHORT", 1),
        ]:
            c_idx = block.find(cmd)
            if c_idx >= 0:
                # Make sure \choice doesn't partially match \choiceTF
                after_cmd = block[c_idx + len(cmd) : c_idx + len(cmd) + 1]
                if after_cmd.isalpha():
                    continue
                args, end_pos = self._extract_brace_args(block, c_idx + len(cmd), max_args=nargs, skip_opt=True)
                if args:
                    choice_mode = mode
                    choices = args
                    block = block[:c_idx] + block[end_pos:]
                    break

        # Clean remaining stem
        stem = re.sub(r"\s+", " ", block).strip()
        # Clean stray }{ or trailing braces from \immini
        stem = stem.strip("{}").strip()

        paras: list[list[tuple[str, bool, bool]]] = []
        paras.append([(f"Câu {q_num}. ", True, False), (stem, False, False)])

        if choice_mode == "ABCD":
            labels = ["A.", "B.", "C.", "D."]
            for idx, opt in enumerate(choices[:4]):
                lbl = labels[idx]
                is_true = r"\True" in opt
                opt_clean = re.sub(r"\\True\s*", "", opt).strip()
                if opt_clean.endswith(r"\\"):
                    opt_clean = opt_clean[:-2].strip()
                underline_lbl = bool(is_true and normalize_true)
                paras.append([(lbl, True, underline_lbl), (f" {opt_clean}", False, False)])

        elif choice_mode == "TF":
            labels = ["a)", "b)", "c)", "d)"]
            for idx, opt in enumerate(choices[:4]):
                lbl = labels[idx]
                is_true = r"\True" in opt
                opt_clean = re.sub(r"\\True\s*", "", opt).strip()
                underline_lbl = bool(is_true and normalize_true)
                paras.append([(lbl, True, underline_lbl), (f" {opt_clean}", False, False)])

        elif choice_mode == "SHORT" and choices:
            ans_clean = choices[0].strip()
            paras.append([("Đáp án: ", True, False), (ans_clean, False, False)])

        if loigiai_text:
            paras.append([("Lời giải", True, False)])
            # Split loigiai by \\ or newlines
            lg_lines = re.split(r"\\\\|\n", loigiai_text)
            for lgl in lg_lines:
                s = lgl.strip()
                if s:
                    paras.append([(s, False, False)])

        return paras

    def _unwrap_macro(self, text: str, macro_name: str, keep_arg_idx: int = 0) -> str:
        cmd = "\\" + macro_name
        while True:
            idx = text.find(cmd)
            if idx < 0:
                break
            args, end_pos = self._extract_brace_args(text, idx + len(cmd), max_args=2, skip_opt=True)
            if not args:
                break
            kept = args[keep_arg_idx] if keep_arg_idx < len(args) else args[0]
            text = text[:idx] + kept + text[end_pos:]
        return text

    @staticmethod
    def _extract_brace_args(
        text: str, pos: int, max_args: int = 4, skip_opt: bool = True
    ) -> tuple[list[str], int]:
        n = len(text)
        while pos < n and text[pos] in " \t\r\n":
            pos += 1
        if skip_opt and pos < n and text[pos] == "[":
            depth = 1
            pos += 1
            while pos < n and depth > 0:
                if text[pos] == "[":
                    depth += 1
                elif text[pos] == "]":
                    depth -= 1
                pos += 1
        args = []
        while len(args) < max_args:
            while pos < n and text[pos] in " \t\r\n":
                pos += 1
            if pos >= n or text[pos] != "{":
                break
            depth = 1
            start = pos + 1
            pos += 1
            while pos < n and depth > 0:
                if text[pos] == "{":
                    depth += 1
                elif text[pos] == "}":
                    depth -= 1
                pos += 1
            args.append(text[start : pos - 1])
        return args, pos

    @staticmethod
    def _set_paragraph_runs(p: etree._Element, runs_spec: list[tuple[str, bool, bool]]):
        p[:] = []
        for text, bold, underline in runs_spec:
            if not text:
                continue
            r = etree.SubElement(p, f"{{{W_NS}}}r")
            rpr = etree.SubElement(r, f"{{{W_NS}}}rPr")
            rfonts = etree.SubElement(rpr, f"{{{W_NS}}}rFonts")
            rfonts.set(f"{{{W_NS}}}ascii", "Times New Roman")
            rfonts.set(f"{{{W_NS}}}hAnsi", "Times New Roman")
            rfonts.set(f"{{{W_NS}}}cs", "Times New Roman")
            if bold:
                etree.SubElement(rpr, f"{{{W_NS}}}b")
            if underline:
                u = etree.SubElement(rpr, f"{{{W_NS}}}u")
                u.set(f"{{{W_NS}}}val", "single")
            sz = etree.SubElement(rpr, f"{{{W_NS}}}sz")
            sz.set(f"{{{W_NS}}}val", "24")
            t = etree.SubElement(r, f"{{{W_NS}}}t")
            if text.startswith(" ") or text.endswith(" ") or "  " in text:
                t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            t.text = text


def convert_docx_latex_to_mathtype(
    input_path: str,
    output_path: str,
    template_path: str = None,
    use_libreoffice: bool = False,
    progress_callback = None,
    lo_threads: int = 4,
    base_pt: float = 11.0,
    **kwargs
) -> dict:
    """
    Public entry point for converting LaTeX math formulas in docx to MathType OLE.
    Replaces old LibreOffice renderer with pure-Python MTEF/WMF engine.
    """
    processor = DocxMathTypeProcessor(base_pt=base_pt)

    def _cb(cur, tot, msg):
        if progress_callback:
            progress_callback(cur, tot, msg)

    out_p, count = processor.process_file(
        input_path=input_path,
        output_path=output_path,
        convert_math=True,
        process_imath=False,
        normalize_true=False,
        progress_cb=_cb if progress_callback else None,
    )
    return {"total": count, "converted": count, "errors": 0}


def find_libreoffice_python() -> str:
    """
    Retained for backward-compatibility.
    Always returns empty string because LibreOffice is no longer needed.
    """
    return ""

