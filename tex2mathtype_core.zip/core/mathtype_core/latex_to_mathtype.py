from dataclasses import dataclass
import math
import re
import struct
try:
    from .ole_wmf_builder import FontOutlineCache, build_ole_object, build_wmf_from_polygons
except (ImportError, ValueError):
    from ole_wmf_builder import FontOutlineCache, build_ole_object, build_wmf_from_polygons

# Constant 86-byte MTEF v5 header (MathType 7 DSMT7, inline default preferences)
MTEF_HEADER = (
    b"\x05\x01\x00\x07\x04DSMT7\x00\x01"
    b"\x13WinAllBasicCodePages\x00"
    b"\x11\x05Times New Roman\x00"
    b"\x11\x03Symbol\x00"
    b"\x11\x05Courier New\x00"
    b"\x11\x04MT Extra\x00"
)

# Known upright function names in LaTeX
KNOWN_FUNCTIONS = {
    "sin": "sin",
    "cos": "cos",
    "tan": "tan",
    "cot": "cot",
    "sec": "sec",
    "csc": "csc",
    "arcsin": "arcsin",
    "arccos": "arccos",
    "arctan": "arctan",
    "arccot": "arccot",
    "sinh": "sinh",
    "cosh": "cosh",
    "tanh": "tanh",
    "coth": "coth",
    "ln": "ln",
    "log": "log",
    "lg": "lg",
    "exp": "exp",
    "lim": "lim",
    "min": "min",
    "max": "max",
    "sup": "sup",
    "inf": "inf",
    "gcd": "gcd",
    "lcm": "lcm",
    "det": "det",
    "deg": "deg",
    "dim": "dim",
    "ker": "ker",
    "hom": "hom",
    "arg": "arg",
    "mod": "mod",
}

# Lowercase Greek letters: name -> (unicode_mtcode, symbol_font_enc_byte)
LC_GREEK = {
    "alpha": (0x03B1, 97),
    "beta": (0x03B2, 98),
    "gamma": (0x03B3, 103),
    "delta": (0x03B4, 100),
    "epsilon": (0x03B5, 101),
    "varepsilon": (0x03B5, 101),
    "zeta": (0x03B6, 122),
    "eta": (0x03B7, 104),
    "theta": (0x03B8, 113),
    "vartheta": (0x03D1, 74),
    "iota": (0x03B9, 105),
    "kappa": (0x03BA, 107),
    "lambda": (0x03BB, 108),
    "mu": (0x03BC, 109),
    "nu": (0x03BD, 110),
    "xi": (0x03BE, 120),
    "pi": (0x03C0, 112),
    "varpi": (0x03D6, 118),
    "rho": (0x03C1, 114),
    "varrho": (0x03F1, 114),
    "sigma": (0x03C3, 115),
    "varsigma": (0x03C2, 86),
    "tau": (0x03C4, 116),
    "upsilon": (0x03C5, 117),
    "phi": (0x03C6, 102),
    "varphi": (0x03D5, 106),
    "chi": (0x03C7, 99),
    "psi": (0x03C8, 121),
    "omega": (0x03C9, 119),
}

# Uppercase Greek letters: name -> (unicode_mtcode, symbol_font_enc_byte)
UC_GREEK = {
    "Gamma": (0x0393, 71),
    "Delta": (0x0394, 68),
    "Theta": (0x0398, 81),
    "Lambda": (0x039B, 76),
    "Xi": (0x039E, 88),
    "Pi": (0x03A0, 80),
    "Sigma": (0x03A3, 83),
    "Upsilon": (0x03A5, 161),
    "Phi": (0x03A6, 70),
    "Psi": (0x03A8, 89),
    "Omega": (0x03A9, 87),
}

# Symbol operators & relations: cmd_or_char -> (tf, mtcode, enc_byte, is_binary_spaced)
SYMBOLS = {
    "+": (0x86, 0x002B, 43, True),
    "-": (0x86, 0x2212, 45, True),
    "=": (0x86, 0x003D, 61, True),
    "<": (0x86, 0x003C, 60, True),
    ">": (0x86, 0x003E, 62, True),
    "le": (0x86, 0x2264, 163, True),
    "leq": (0x86, 0x2264, 163, True),
    "leqslant": (0x86, 0x2264, 163, True),
    "ge": (0x86, 0x2265, 179, True),
    "geq": (0x86, 0x2265, 179, True),
    "geqslant": (0x86, 0x2265, 179, True),
    "ne": (0x86, 0x2260, 185, True),
    "neq": (0x86, 0x2260, 185, True),
    "approx": (0x86, 0x2248, 187, True),
    "equiv": (0x86, 0x2261, 186, True),
    "sim": (0x86, 0x223C, 126, True),
    "backsim": (0x86, 0x223D, 126, True),
    "simeq": (0x86, 0x2243, 64, True),
    "cong": (0x86, 0x2245, 64, True),
    "pm": (0x86, 0x00B1, 177, True),
    "mp": (0x86, 0x2213, 177, True),
    "cdot": (0x86, 0x22C5, 215, True),
    "times": (0x86, 0x00D7, 180, True),
    "div": (0x86, 0x00F7, 184, True),
    "frown": (0x96, 0x2322, 0x22, True),
    "ast": (0x86, 0x2217, 42, True),
    "circ": (0x86, 0x00B0, 176, False),
    "degree": (0x86, 0x00B0, 176, False),
    "in": (0x86, 0x2208, 206, True),
    "notin": (0x86, 0x2209, 207, True),
    "ni": (0x86, 0x220B, 39, True),
    "subset": (0x86, 0x2282, 204, True),
    "subseteq": (0x86, 0x2286, 205, True),
    "supset": (0x86, 0x2283, 201, True),
    "supseteq": (0x86, 0x2287, 202, True),
    "cup": (0x86, 0x222A, 200, True),
    "cap": (0x86, 0x2229, 199, True),
    "setminus": (0x86, 0x2216, 92, True),
    "emptyset": (0x86, 0x2205, 198, False),
    "varnothing": (0x86, 0x2205, 198, False),
    "infty": (0x86, 0x221E, 165, False),
    "forall": (0x86, 0x2200, 34, False),
    "exists": (0x86, 0x2203, 36, False),
    "partial": (0x86, 0x2202, 182, False),
    "nabla": (0x86, 0x2207, 209, False),
    "perp": (0x86, 0x22A5, 94, True),
    "parallel": (0x8B, 0x2225, 80, True),
    "Rightarrow": (0x86, 0x21D2, 222, True),
    "implies": (0x86, 0x21D2, 222, True),
    "Leftarrow": (0x86, 0x21D0, 220, True),
    "Leftrightarrow": (0x86, 0x21D4, 219, True),
    "iff": (0x86, 0x21D4, 219, True),
    "rightarrow": (0x86, 0x2192, 174, True),
    "to": (0x86, 0x2192, 174, True),
    "leftarrow": (0x86, 0x2190, 172, True),
    "longmapsto": (0x86, 0x2192, 174, True),
    "mapsto": (0x86, 0x2192, 174, True),
    "triangle": (0x86, 0x2206, 68, False),
    "bigtriangleup": (0x86, 0x2206, 68, False),
    "angle": (0x86, 0x2220, 208, False),
    "widehat_ angle": (0x86, 0x2220, 208, False),
    "dots": (0x86, 0x2026, 188, False),
    "ldots": (0x86, 0x2026, 188, False),
    "cdots": (0x86, 0x2026, 188, False),
    "int": (0x86, 0x222B, 242, False),
    "oint": (0x86, 0x222B, 242, False),
    "sum": (0x86, 0x2211, 229, False),
    "prod": (0x86, 0x220F, 213, False),
}


@dataclass
class ConvertedEquation:
    mtef_bytes: bytes
    ole_bytes: bytes
    wmf_bytes: bytes
    width_pt: float
    height_pt: float
    dxa_orig: int
    dya_orig: int
    pos_half_pts: int


@dataclass
class LayoutBox:
    width: float
    ascent: float
    descent: float
    polygons: list[list[tuple[float, float]]]


class LaTeXToMathTypeConverter:
    """
    High-speed, pure-Python LaTeX -> MathType 7 (Equation.DSMT4 OLE + WMF) converter.
    Caches converted formulas in memory so duplicate formulas across a document take 0 ms.
    """

    def __init__(self, base_pt: float = 11.0):
        self.font_cache = FontOutlineCache()
        self._cache: dict[str, ConvertedEquation] = {}
        self.base_pt = base_pt

    def convert(self, latex: str) -> ConvertedEquation:
        norm = latex.strip()
        if norm.startswith("$$") and norm.endswith("$$"):
            norm = norm[2:-2].strip()
        elif norm.startswith("$") and norm.endswith("$"):
            norm = norm[1:-1].strip()
        elif norm.startswith(r"\[") and norm.endswith(r"\]"):
            norm = norm[2:-2].strip()
        elif norm.startswith(r"\(") and norm.endswith(r"\)"):
            norm = norm[2:-2].strip()

        # Clean trailing \\ or whitespace inside math formula
        if norm.endswith(r"\\"):
            norm = norm[:-2].strip()
        # Clean leading \True if included inside formula delimiters
        if norm.startswith(r"\True"):
            norm = norm[len(r"\True"):].strip()

        if norm in self._cache:
            return self._cache[norm]

        tokens = self._tokenize(norm)
        ast, _ = self._parse_expr(tokens, 0, stop_tokens=set())

        scale_root = self.base_pt / 12.0
        mtef_body, box = self._compile_nodes(ast, scale=scale_root, in_script=False)
        mtef_bytes = MTEF_HEADER + b"\x0a\x01\x00" + mtef_body + b"\x00\x00"
        ole_bytes = build_ole_object(mtef_bytes)

        # Convert LayoutBox into WMF coordinates
        pad_x = 1.0 * scale_root
        pad_y = 0.5 * scale_root
        width_pt = max(2.0, round(box.width + 2.0 * pad_x, 2))
        height_pt = max(4.0, round(box.ascent + box.descent + 2.0 * pad_y, 2))

        units_per_pt = 800
        while (width_pt * units_per_pt > 32000 or height_pt * units_per_pt > 32000) and units_per_pt > 50:
            units_per_pt //= 2
        inch = units_per_pt * 72
        r = max(1, int(round(width_pt * units_per_pt)))
        b = max(1, int(round(height_pt * units_per_pt)))

        baseline_y = (box.ascent + pad_y) * units_per_pt
        wmf_polys = []
        for poly in box.polygons:
            wpoly = [
                (
                    int(round((px + pad_x) * units_per_pt)),
                    int(round(baseline_y - py * units_per_pt)),
                )
                for px, py in poly
            ]
            if len(wpoly) >= 3:
                wmf_polys.append(wpoly)

        wmf_bytes = build_wmf_from_polygons(wmf_polys, r, b, inch)
        dxa_orig = int(round(width_pt * 20.0))
        dya_orig = int(round(height_pt * 20.0))
        descent_from_bottom_pt = box.descent + pad_y
        pos_half_pts = -max(1, int(round(descent_from_bottom_pt * 2.0)))

        res = ConvertedEquation(
            mtef_bytes=mtef_bytes,
            ole_bytes=ole_bytes,
            wmf_bytes=wmf_bytes,
            width_pt=width_pt,
            height_pt=height_pt,
            dxa_orig=dxa_orig,
            dya_orig=dya_orig,
            pos_half_pts=pos_half_pts,
        )
        self._cache[norm] = res
        return res

    def _tokenize(self, s: str) -> list[str]:
        # Preprocess common Vietnamese / iMath LaTeX shorthands
        s = s.replace(r"\allowdisplaybreaks", "")
        s = s.replace(r"\displaystyle", "")
        s = s.replace(r"\textstyle", "")
        s = s.replace(r"\limits", "")
        s = s.replace(r"\nolimits", "")
        tokens = []
        i = 0
        n = len(s)
        while i < n:
            ch = s[i]
            if ch in " \t\r\n":
                i += 1
            elif ch == "\\":
                if i + 1 < n and s[i + 1] in r"{},:;! \|":
                    tokens.append(s[i : i + 2])
                    i += 2
                else:
                    j = i + 1
                    while j < n and s[j].isalpha():
                        j += 1
                    cmd = s[i:j]
                    if cmd in (r"\text", r"\mathrm", r"\textrm", r"\textbf", r"\textit", r"\mbox"):
                        while j < n and s[j] in " \t":
                            j += 1
                        if j < n and s[j] == "{":
                            depth = 1
                            k = j + 1
                            while k < n and depth > 0:
                                if s[k] == "{":
                                    depth += 1
                                elif s[k] == "}":
                                    depth -= 1
                                k += 1
                            txt_content = s[j + 1 : k - 1]
                            tokens.append(f"__TEXT__:{txt_content}")
                            i = k
                            continue
                    tokens.append(cmd)
                    i = j
            elif ch in "{}[]()_^+-=<>,.;:/|!'":
                tokens.append(ch)
                i += 1
            else:
                tokens.append(ch)
                i += 1
        return tokens

    def _parse_expr(self, tokens: list[str], pos: int, stop_tokens: set[str]) -> tuple[list[dict], int]:
        nodes = []
        n = len(tokens)
        while pos < n:
            tok = tokens[pos]
            if tok in stop_tokens or tok == "}" or tok == r"\right" or tok.startswith(r"\end"):
                break
            node, pos = self._parse_atom(tokens, pos)
            if node is not None:
                # Check for postfix primes, subscripts, superscripts
                sub_ast = None
                sup_ast = None
                primes = 0
                while pos < n:
                    ntok = tokens[pos]
                    if ntok == "'":
                        primes += 1
                        pos += 1
                    elif ntok == "_":
                        pos += 1
                        sub_node, pos = self._parse_script_arg(tokens, pos)
                        sub_ast = sub_node
                    elif ntok == "^":
                        pos += 1
                        sup_node, pos = self._parse_script_arg(tokens, pos)
                        sup_ast = sup_node
                    else:
                        break
                if primes > 0:
                    nodes.append(node)
                    for _ in range(primes):
                        nodes.append({"type": "prime"})
                    if sub_ast is not None or sup_ast is not None:
                        nodes.append({"type": "script", "sub": sub_ast, "sup": sup_ast})
                elif sub_ast is not None or sup_ast is not None:
                    # Check if sup_ast is sole \circ / ^\circ -> attach directly or use script
                    if sub_ast is None and sup_ast == [{"type": "sym", "name": "circ"}]:
                        nodes.append(node)
                        nodes.append({"type": "sym", "name": "circ"})
                    else:
                        nodes.append(node)
                        nodes.append({"type": "script", "sub": sub_ast, "sup": sup_ast})
                else:
                    nodes.append(node)
        return nodes, pos

    def _parse_script_arg(self, tokens: list[str], pos: int) -> tuple[list[dict], int]:
        if pos >= len(tokens):
            return [], pos
        if tokens[pos] == "{":
            inner, pos = self._parse_expr(tokens, pos + 1, stop_tokens={"}"})
            if pos < len(tokens) and tokens[pos] == "}":
                pos += 1
            return inner, pos
        atom, pos = self._parse_atom(tokens, pos)
        return ([atom] if atom else []), pos

    def _parse_atom(self, tokens: list[str], pos: int) -> tuple[dict | None, int]:
        if pos >= len(tokens):
            return None, pos
        tok = tokens[pos]
        pos += 1

        if tok == "{":
            inner, pos = self._parse_expr(tokens, pos, stop_tokens={"}"})
            if pos < len(tokens) and tokens[pos] == "}":
                pos += 1
            return {"type": "group", "body": inner}, pos

        if tok.startswith("__TEXT__:"):
            return {"type": "text", "text": tok[9:]}, pos

        if tok in (r"\frac", r"\dfrac", r"\tfrac", r"\cfrac"):
            num, pos = self._parse_script_arg(tokens, pos)
            den, pos = self._parse_script_arg(tokens, pos)
            return {"type": "frac", "num": num, "den": den}, pos

        if tok == r"\sqrt":
            deg = None
            if pos < len(tokens) and tokens[pos] == "[":
                deg, pos = self._parse_expr(tokens, pos + 1, stop_tokens={"]"})
                if pos < len(tokens) and tokens[pos] == "]":
                    pos += 1
            rad, pos = self._parse_script_arg(tokens, pos)
            return {"type": "sqrt", "deg": deg, "rad": rad}, pos

        if tok in (r"\widehat", r"\hat"):
            arg, pos = self._parse_script_arg(tokens, pos)
            return {"type": "hat", "body": arg}, pos

        if tok in (r"\widetilde", r"\tilde"):
            arg, pos = self._parse_script_arg(tokens, pos)
            return {"type": "tilde", "body": arg}, pos

        if tok in (r"\overline", r"\bar"):
            arg, pos = self._parse_script_arg(tokens, pos)
            return {"type": "obar", "body": arg}, pos

        if tok == r"\underline":
            arg, pos = self._parse_script_arg(tokens, pos)
            return {"type": "ubar", "body": arg}, pos

        if tok in (r"\overrightarrow", r"\vec"):
            arg, pos = self._parse_script_arg(tokens, pos)
            return {"type": "vec", "body": arg}, pos

        if tok in (r"\wideparen", r"\overparen", r"\arc", r"\widearc", r"\overarc"):
            arg, pos = self._parse_script_arg(tokens, pos)
            return {"type": "arc", "body": arg}, pos

        if tok in (r"\heva", r"\hoac"):
            rows, pos = self._parse_pile_braced(tokens, pos)
            return {"type": "system", "kind": "heva" if tok == r"\heva" else "hoac", "rows": rows}, pos

        if tok == r"\begin":
            env_name = "matrix"
            if pos < len(tokens) and tokens[pos] == "{":
                env_tokens, pos = self._parse_expr(tokens, pos + 1, stop_tokens={"}"})
                if pos < len(tokens) and tokens[pos] == "}":
                    pos += 1
                env_name = "".join(t.get("ch", "") for t in env_tokens)
            rows, pos = self._parse_env_rows(tokens, pos)
            if env_name == "cases":
                return {"type": "system", "kind": "heva", "rows": rows}, pos
            elif env_name == "pmatrix":
                return {"type": "fence", "left": "(", "right": ")", "body": [{"type": "pile", "rows": rows}]}, pos
            elif env_name == "bmatrix":
                return {"type": "fence", "left": "[", "right": "]", "body": [{"type": "pile", "rows": rows}]}, pos
            elif env_name == "vmatrix":
                return {"type": "fence", "left": "|", "right": "|", "body": [{"type": "pile", "rows": rows}]}, pos
            else:
                return {"type": "pile", "rows": rows}, pos

        if tok == r"\left":
            left_delim = "("
            if pos < len(tokens):
                left_delim = tokens[pos]
                pos += 1
            inner, pos = self._parse_expr(tokens, pos, stop_tokens={r"\right"})
            right_delim = ")"
            if pos < len(tokens) and tokens[pos] == r"\right":
                pos += 1
                if pos < len(tokens):
                    right_delim = tokens[pos]
                    pos += 1
            return {"type": "fence", "left": left_delim, "right": right_delim, "body": inner}, pos

        if tok in (r"\,", r"\:", r"\;", r"\quad", r"\qquad", r"\ "):
            return {"type": "space", "thin": True}, pos
        if tok == r"\!":
            return None, pos

        if tok.startswith("\\"):
            cname = tok[1:]
            if cname in KNOWN_FUNCTIONS:
                return {"type": "func", "name": KNOWN_FUNCTIONS[cname]}, pos
            if cname in LC_GREEK:
                return {"type": "lcgreek", "name": cname}, pos
            if cname in UC_GREEK:
                return {"type": "ucgreek", "name": cname}, pos
            if cname == "colon":
                return {"type": "char", "ch": ":"}, pos
            if cname in SYMBOLS:
                return {"type": "sym", "name": cname}, pos
            if cname in ("{", "}", "|"):
                return {"type": "char", "ch": cname}, pos
            if cname in ("mathbb", "mathcal", "mathfrak", "mathbf", "mathsf"):
                arg, pos = self._parse_script_arg(tokens, pos)
                return {"type": "group", "body": arg}, pos
            # Fallback: treat unknown macro with no args as function/text
            return {"type": "func", "name": cname}, pos

        if tok in SYMBOLS:
            return {"type": "sym", "name": tok}, pos

        return {"type": "char", "ch": tok}, pos

    def _parse_pile_braced(self, tokens: list[str], pos: int) -> tuple[list[list[dict]], int]:
        if pos >= len(tokens) or tokens[pos] != "{":
            return [[]], pos
        pos += 1
        rows = []
        curr_tokens = []
        depth = 1
        n = len(tokens)
        while pos < n and depth > 0:
            t = tokens[pos]
            if t == "{":
                depth += 1
                curr_tokens.append(t)
            elif t == "}":
                depth -= 1
                if depth > 0:
                    curr_tokens.append(t)
            elif depth == 1 and t == r"\\":
                row_ast, _ = self._parse_expr(curr_tokens, 0, stop_tokens=set())
                rows.append(row_ast)
                curr_tokens = []
            elif depth == 1 and t == "&":
                pass
            else:
                curr_tokens.append(t)
            pos += 1
        if curr_tokens or not rows:
            row_ast, _ = self._parse_expr(curr_tokens, 0, stop_tokens=set())
            rows.append(row_ast)
        return rows, pos

    def _parse_env_rows(self, tokens: list[str], pos: int) -> tuple[list[list[dict]], int]:
        rows = []
        curr_tokens = []
        depth = 0
        n = len(tokens)
        while pos < n:
            t = tokens[pos]
            if t == r"\begin":
                depth += 1
                curr_tokens.append(t)
                pos += 1
            elif t == r"\end":
                if depth == 0:
                    pos += 1
                    if pos < n and tokens[pos] == "{":
                        _, pos = self._parse_expr(tokens, pos + 1, stop_tokens={"}"})
                        if pos < n and tokens[pos] == "}":
                            pos += 1
                    break
                depth -= 1
                curr_tokens.append(t)
                pos += 1
            elif depth == 0 and t == r"\\":
                row_ast, _ = self._parse_expr(curr_tokens, 0, stop_tokens=set())
                rows.append(row_ast)
                curr_tokens = []
                pos += 1
            elif depth == 0 and t == "&":
                curr_tokens.append(r"\,")
                pos += 1
            else:
                curr_tokens.append(t)
                pos += 1
        if curr_tokens or not rows:
            row_ast, _ = self._parse_expr(curr_tokens, 0, stop_tokens=set())
            rows.append(row_ast)
        return rows, pos

    def _compile_nodes(self, nodes: list[dict], scale: float = 1.0, in_script: bool = False) -> tuple[bytes, LayoutBox]:
        mtef_parts = []
        boxes = []

        # Flatten top-level single-item groups for cleaner operator spacing detection
        flat_nodes = []
        for nd in nodes:
            if nd["type"] == "group" and len(nd["body"]) == 1:
                flat_nodes.append(nd["body"][0])
            else:
                flat_nodes.append(nd)

        n = len(flat_nodes)
        for idx, nd in enumerate(flat_nodes):
            ntype = nd["type"]

            # Automatic spacing around binary operators at top level (not inside scripts)
            if ntype == "sym":
                sname = nd["name"]
                tf, mtcode, enc, is_bin = SYMBOLS[sname]
                # Check if unary '+' or '-' (at start of expression or right after another binary operator or open paren)
                prev_type = flat_nodes[idx - 1]["type"] if idx > 0 else None
                prev_is_open = (
                    prev_type is None
                    or (prev_type == "sym" and SYMBOLS[flat_nodes[idx - 1]["name"]][3])
                    or (prev_type == "char" and flat_nodes[idx - 1]["ch"] in "([,;:=")
                )
                use_space = is_bin and not in_script and not (sname in ("+", "-") and prev_is_open)
                if use_space and idx > 0:
                    sp_m, sp_b = self._make_char_mtef_and_box(0x00, 0x81, 0x0020, None, scale)
                    mtef_parts.append(sp_m)
                    boxes.append(sp_b)

                sym_m, sym_b = self._make_char_mtef_and_box(0x04, tf, mtcode, enc, scale)
                mtef_parts.append(sym_m)
                boxes.append(sym_b)

                if use_space and idx + 1 < n:
                    sp_m, sp_b = self._make_char_mtef_and_box(0x00, 0x81, 0x0020, None, scale)
                    mtef_parts.append(sp_m)
                    boxes.append(sp_b)

                # If degree symbol \circ is followed by unit letters like C, keep tight
                continue

            if ntype == "space":
                # Thin space in MTEF: tf=0x98, mtcode=0xEF02
                mtef_parts.append(b"\x02\x00\x98\x02\xef")
                boxes.append(LayoutBox(width=2.2 * scale, ascent=6.0 * scale, descent=0.0, polygons=[]))
                continue

            if ntype == "prime":
                # MathType prime: FONT_STYLE_DEF(8, 2, 0) + CHAR(opt=4, tf=0x7f, mtcode=0x2032, enc=162)
                mtef_parts.append(b"\x08\x02\x00\x02\x04\x7f\x32\x20\xa2")
                _, b_prime = self._make_char_mtef_and_box(0x04, 0x86, 0x2032, 162, scale)
                boxes.append(b_prime)
                continue

            if ntype == "char":
                ch = nd["ch"]
                if ch.isdigit() or ch == ".":
                    cm, cb = self._make_char_mtef_and_box(0x00, 0x88, ord(ch), None, scale)
                elif ch in "(),/[];:!":
                    cm, cb = self._make_char_mtef_and_box(0x00, 0x82, ord(ch), None, scale)
                    if ch == ";" and not in_script and idx + 1 < n:
                        mtef_parts.append(cm)
                        boxes.append(cb)
                        sp_m, sp_b = self._make_char_mtef_and_box(0x00, 0x81, 0x0020, None, scale)
                        mtef_parts.append(sp_m)
                        boxes.append(sp_b)
                        continue
                elif ch.isalpha() and ord(ch) < 128:
                    cm, cb = self._make_char_mtef_and_box(0x00, 0x83, ord(ch), None, scale)
                elif ord(ch) > 255:
                    cm, cb = self._make_char_mtef_and_box(0x10, 0x81, ord(ch), ord(ch), scale)
                else:
                    cm, cb = self._make_char_mtef_and_box(0x00, 0x81, ord(ch), None, scale)
                mtef_parts.append(cm)
                boxes.append(cb)
                continue

            if ntype == "text":
                txt = nd["text"]
                for ch in txt:
                    if ord(ch) > 255:
                        cm, cb = self._make_char_mtef_and_box(0x10, 0x81, ord(ch), ord(ch), scale)
                    else:
                        cm, cb = self._make_char_mtef_and_box(0x00, 0x81, ord(ch), None, scale)
                    mtef_parts.append(cm)
                    boxes.append(cb)
                continue

            if ntype == "func":
                fname = nd["name"]
                for c_i, ch in enumerate(fname):
                    opt = 0x02 if c_i == 0 else 0x00
                    cm, cb = self._make_char_mtef_and_box(opt, 0x82, ord(ch), None, scale)
                    mtef_parts.append(cm)
                    boxes.append(cb)
                # Add space after function if next node is not script or fence or paren
                if idx + 1 < n:
                    nxt = flat_nodes[idx + 1]
                    if nxt["type"] not in ("script", "fence", "hat") and not (
                        nxt["type"] == "char" and nxt.get("ch") in "([|"
                    ):
                        sp_m, sp_b = self._make_char_mtef_and_box(0x00, 0x81, 0x0020, None, scale)
                        mtef_parts.append(sp_m)
                        boxes.append(sp_b)
                    elif nxt["type"] == "hat":
                        boxes.append(LayoutBox(width=2.0 * scale, ascent=6.0 * scale, descent=0.0, polygons=[]))
                continue

            if ntype == "lcgreek":
                mtcode, enc = LC_GREEK[nd["name"]]
                cm, cb = self._make_char_mtef_and_box(0x04, 0x84, mtcode, enc, scale)
                mtef_parts.append(cm)
                boxes.append(cb)
                continue

            if ntype == "ucgreek":
                mtcode, enc = UC_GREEK[nd["name"]]
                cm, cb = self._make_char_mtef_and_box(0x04, 0x85, mtcode, enc, scale)
                mtef_parts.append(cm)
                boxes.append(cb)
                continue

            if ntype == "group":
                gm, gb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(gm)
                boxes.append(gb)
                continue

            if ntype == "frac":
                nm, nb = self._compile_nodes(nd["num"], scale=scale, in_script=True)
                dm, db = self._compile_nodes(nd["den"], scale=scale, in_script=True)
                mtef_parts.append(b"\x03\x00\x0b\x00\x00\x01\x00" + nm + b"\x00\x01\x00" + dm + b"\x00\x00")
                boxes.append(self._layout_frac(nb, db, scale))
                continue

            if ntype == "sqrt":
                rm, rb = self._compile_nodes(nd["rad"], scale=scale, in_script=True)
                if nd["deg"] is None:
                    mtef_parts.append(b"\x03\x00\x0a\x00\x00\x01\x00" + rm + b"\x00\x0b\x01\x01\x00\x0a")
                    boxes.append(self._layout_sqrt(rb, None, scale))
                else:
                    dgm, dgb = self._compile_nodes(nd["deg"], scale=scale * 0.62, in_script=True)
                    mtef_parts.append(
                        b"\x03\x00\x0a\x01\x00\x01\x00" + rm + b"\x00\x0b\x01\x00" + dgm + b"\x00\x00\x0a"
                    )
                    boxes.append(self._layout_sqrt(rb, dgb, scale))
                continue

            if ntype == "script":
                sub_nodes = nd["sub"]
                sup_nodes = nd["sup"]
                sub_scale = scale * 0.64
                if sub_nodes is not None and sup_nodes is not None:
                    sbm, sbb = self._compile_nodes(sub_nodes, scale=sub_scale, in_script=True)
                    spm, spb = self._compile_nodes(sup_nodes, scale=sub_scale, in_script=True)
                    mtef_parts.append(
                        b"\x03\x00\x1d\x00\x00\x0b\x01\x00" + sbm + b"\x00\x01\x00" + spm + b"\x00\x00\x0a"
                    )
                elif sup_nodes is not None:
                    spm, spb = self._compile_nodes(sup_nodes, scale=sub_scale, in_script=True)
                    sbb = None
                    mtef_parts.append(b"\x03\x00\x1c\x00\x00\x0b\x01\x01\x01\x00" + spm + b"\x00\x00\x0a")
                else:
                    sbm, sbb = self._compile_nodes(sub_nodes, scale=sub_scale, in_script=True)
                    spb = None
                    mtef_parts.append(b"\x03\x00\x1b\x00\x00\x0b\x01\x00" + sbm + b"\x00\x01\x01\x00\x0a")
                prev_ascent = boxes[-1].ascent if boxes else 7.5 * scale
                prev_descent = boxes[-1].descent if boxes else 0.0
                boxes.append(self._layout_script(sbb, spb, prev_ascent, prev_descent, scale))
                continue

            if ntype == "hat":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(b"\x03\x00\x21\x00\x00\x01\x00" + bm + b"\x00\x02\x00\x96\x02\x03\x00")
                boxes.append(self._layout_accent(bb, "hat", scale))
                continue

            if ntype == "tilde":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(b"\x03\x00\x20\x00\x00\x01\x00" + bm + b"\x00\x02\x00\x96\x03\x03\x00")
                boxes.append(self._layout_accent(bb, "tilde", scale))
                continue

            if ntype == "obar":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(b"\x03\x00\x0d\x00\x00\x01\x00" + bm + b"\x00\x00")
                boxes.append(self._layout_accent(bb, "obar", scale))
                continue

            if ntype == "ubar":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(b"\x03\x00\x0c\x00\x00\x01\x00" + bm + b"\x00\x00")
                boxes.append(self._layout_accent(bb, "ubar", scale))
                continue

            if ntype == "vec":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(b"\x03\x00\x1f\x02\x00\x01\x00" + bm + b"\x00\x02\x00\x96\xd7\x20\x00")
                boxes.append(self._layout_accent(bb, "vec", scale))
                continue

            if ntype == "arc":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                mtef_parts.append(b"\x03\x00\x22\x00\x00\x01\x00" + bm + b"\x00\x02\x00\x96\x22\x23\x00")
                boxes.append(self._layout_accent(bb, "arc", scale))
                continue

            if ntype == "fence":
                bm, bb = self._compile_nodes(nd["body"], scale=scale, in_script=in_script)
                ld, rd = nd["left"], nd["right"]
                fm, fb = self._build_fence(ld, rd, bm, bb, scale)
                mtef_parts.append(fm)
                boxes.append(fb)
                continue

            if ntype == "system":
                row_mtefs = []
                row_boxes = []
                for r_ast in nd["rows"]:
                    rm, rb = self._compile_nodes(r_ast, scale=scale, in_script=False)
                    row_mtefs.append(b"\x01\x00" + rm + b"\x00")
                    row_boxes.append(rb)
                pile_mtef = b"\x04\x00\x01\x02" + b"".join(row_mtefs) + b"\x00"
                pile_box = self._layout_pile(row_boxes, scale)
                if nd["kind"] == "heva":
                    # Left curly brace: sel=2 (tmBRACE), var=1 (left only)
                    mtef_parts.append(
                        b"\x03\x00\x02\x01\x00\x01\x00" + pile_mtef + b"\x00\x02\x00\x96\x7b\x00\x00"
                    )
                    boxes.append(self._layout_fenced_box("{", ".", pile_box, scale))
                else:
                    # Left square bracket: sel=3 (tmBRACK), var=1 (left only)
                    mtef_parts.append(
                        b"\x03\x00\x03\x01\x00\x01\x00" + pile_mtef + b"\x00\x02\x00\x96\x5b\x00\x00"
                    )
                    boxes.append(self._layout_fenced_box("[", ".", pile_box, scale))
                continue

            if ntype == "pile":
                row_mtefs = []
                row_boxes = []
                for r_ast in nd["rows"]:
                    rm, rb = self._compile_nodes(r_ast, scale=scale, in_script=False)
                    row_mtefs.append(b"\x01\x00" + rm + b"\x00")
                    row_boxes.append(rb)
                pile_mtef = b"\x04\x00\x01\x02" + b"".join(row_mtefs) + b"\x00"
                mtef_parts.append(pile_mtef)
                boxes.append(self._layout_pile(row_boxes, scale))
                continue

        return b"".join(mtef_parts), self._concat_boxes(boxes, scale)

    def _make_char_mtef_and_box(
        self, opt: int, tf: int, mtcode: int, enc: int | None, scale: float
    ) -> tuple[bytes, LayoutBox]:
        if opt & 0x04 and enc is not None:
            mtef = struct.pack("<BBBHB", 2, opt, tf, mtcode, enc)
        elif opt & 0x10 and enc is not None:
            mtef = struct.pack("<BBBHH", 2, opt, tf, mtcode, enc)
        else:
            mtef = struct.pack("<BBBH", 2, opt, tf, mtcode)

        # Choose font style for outline extraction
        if tf == 0x83:
            style = "italic"
            code = mtcode
        elif tf in (0x84, 0x85, 0x86, 0x7F):
            if mtcode == 0x223D:
                style = "seguisym"
                code = 0x223D
            else:
                style = "symbol"
                code = enc if enc is not None else mtcode
        elif tf in (0x8B, 0x96):
            style = "mtextra"
            code = enc if enc is not None else mtcode
        else:
            style = "roman"
            code = mtcode

        pt_size = 12.0 * scale
        if mtcode == 0x0020:
            return mtef, LayoutBox(width=0.30 * pt_size, ascent=0.68 * pt_size, descent=0.0, polygons=[])

        adv_em, lsb_em, bbox_em, contours_em = self.font_cache.get_glyph(style, code)
        shift_x = max(0.0, -lsb_em * pt_size) + 0.04 * pt_size
        polys = [[(x * pt_size + shift_x, y * pt_size) for (x, y) in c] for c in contours_em]
        w = max(adv_em * pt_size, bbox_em[2] * pt_size) + shift_x + 0.04 * pt_size
        asc = max(0.68 * pt_size, bbox_em[3] * pt_size)
        desc = max(0.0, -bbox_em[1] * pt_size)
        return mtef, LayoutBox(width=w, ascent=asc, descent=desc, polygons=polys)

    def _concat_boxes(self, boxes: list[LayoutBox], scale: float) -> LayoutBox:
        if not boxes:
            return LayoutBox(width=2.0 * scale, ascent=8.0 * scale, descent=0.0, polygons=[])
        cursor_x = 0.0
        asc = 8.0 * scale
        desc = 0.0
        all_polys = []
        for b in boxes:
            asc = max(asc, b.ascent)
            desc = max(desc, b.descent)
            for p in b.polygons:
                all_polys.append([(x + cursor_x, y) for (x, y) in p])
            cursor_x += b.width
        return LayoutBox(width=cursor_x, ascent=asc, descent=desc, polygons=all_polys)

    @staticmethod
    def _rect_poly(x0: float, y0: float, x1: float, y1: float) -> list[tuple[float, float]]:
        return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]

    def _layout_frac(self, num: LayoutBox, den: LayoutBox, scale: float) -> LayoutBox:
        axis = 3.2 * scale
        bar_t = 0.55 * scale
        pad_x = 1.6 * scale
        gap = 2.6 * scale
        w = max(num.width, den.width) + 2.0 * pad_x

        num_x = (w - num.width) * 0.5
        num_y = axis + gap + num.descent
        den_x = (w - den.width) * 0.5
        den_y = axis - gap - den.ascent

        polys = []
        for p in num.polygons:
            polys.append([(x + num_x, y + num_y) for (x, y) in p])
        for p in den.polygons:
            polys.append([(x + den_x, y + den_y) for (x, y) in p])
        polys.append(self._rect_poly(0.3 * scale, axis - bar_t * 0.5, w - 0.3 * scale, axis + bar_t * 0.5))

        asc = num_y + num.ascent
        desc = max(0.0, -(den_y - den.descent))
        return LayoutBox(width=w, ascent=asc, descent=desc, polygons=polys)

    def _layout_sqrt(self, rad: LayoutBox, deg: LayoutBox | None, scale: float) -> LayoutBox:
        bar_t = 0.52 * scale
        gap_top = 1.2 * scale
        top_y = rad.ascent + gap_top + bar_t
        bot_y = -rad.descent - 0.3 * scale
        h = top_y - bot_y

        hook_w = 5.6 * scale
        left_pad = 0.4 * scale
        if deg is not None:
            left_pad = max(left_pad, deg.width - 2.2 * scale)

        rad_x = left_pad + hook_w
        right_pad = 1.0 * scale
        total_w = rad_x + rad.width + right_pad

        polys = []
        if deg is not None:
            deg_x = left_pad
            deg_y = bot_y + h * 0.55
            for p in deg.polygons:
                polys.append([(x + deg_x, y + deg_y) for (x, y) in p])

        for p in rad.polygons:
            polys.append([(x + rad_x, y) for (x, y) in p])

        # Radical sign V-hook + overbar polygon
        x0 = left_pad
        y_mid = bot_y + h * 0.42
        x_v = left_pad + hook_w * 0.42
        x_top = rad_x
        t = bar_t
        hook_poly = [
            (x0, y_mid),
            (x0 + hook_w * 0.16, y_mid + t * 0.8),
            (x_v, bot_y + t * 1.4),
            (x_top - t * 0.3, top_y),
            (total_w, top_y),
            (total_w, top_y - t),
            (x_top + t * 0.2, top_y - t),
            (x_v, bot_y),
            (x0 + hook_w * 0.10, y_mid - t * 0.3),
        ]
        polys.append(hook_poly)
        return LayoutBox(width=total_w, ascent=top_y, descent=max(0.5 * scale, -bot_y), polygons=polys)

    def _layout_script(
        self,
        sub: LayoutBox | None,
        sup: LayoutBox | None,
        prev_ascent: float,
        prev_descent: float,
        scale: float,
    ) -> LayoutBox:
        polys = []
        w = 0.4 * scale
        asc = prev_ascent
        desc = prev_descent
        if sup is not None:
            sup_y = max(4.4 * scale, prev_ascent - 2.6 * scale)
            for p in sup.polygons:
                polys.append([(x + 0.3 * scale, y + sup_y) for (x, y) in p])
            w = max(w, sup.width + 0.5 * scale)
            asc = max(asc, sup_y + sup.ascent)
        if sub is not None:
            sub_y = -max(2.3 * scale, prev_descent + 1.0 * scale)
            for p in sub.polygons:
                polys.append([(x + 0.3 * scale, y + sub_y) for (x, y) in p])
            w = max(w, sub.width + 0.5 * scale)
            desc = max(desc, -(sub_y - sub.descent))
        return LayoutBox(width=w, ascent=asc, descent=desc, polygons=polys)

    def _layout_accent(self, body: LayoutBox, kind: str, scale: float) -> LayoutBox:
        polys = [list(p) for p in body.polygons]
        w = body.width
        t = 0.5 * scale
        y_base = body.ascent + 0.8 * scale
        if kind == "hat":
            hw = max(4.5 * scale, w * 0.85)
            cx = w * 0.5
            x_l = cx - hw * 0.5
            x_r = cx + hw * 0.5
            peak_y = y_base + 1.9 * scale
            hat_poly = [
                (x_l, y_base),
                (cx, peak_y),
                (x_r, y_base),
                (x_r - t * 0.6, y_base - t * 0.7),
                (cx, peak_y - t * 1.2),
                (x_l + t * 0.6, y_base - t * 0.7),
            ]
            polys.append(hat_poly)
            return LayoutBox(width=w, ascent=peak_y + 0.3 * scale, descent=body.descent, polygons=polys)
        elif kind == "obar" or kind == "tilde":
            polys.append(self._rect_poly(0.2 * scale, y_base, w - 0.2 * scale, y_base + t))
            return LayoutBox(width=w, ascent=y_base + t + 0.3 * scale, descent=body.descent, polygons=polys)
        elif kind == "ubar":
            yb = -body.descent - 1.0 * scale
            polys.append(self._rect_poly(0.2 * scale, yb - t, w - 0.2 * scale, yb))
            return LayoutBox(width=w, ascent=body.ascent, descent=-yb + t + 0.3 * scale, polygons=polys)
        elif kind == "vec":
            y_m = y_base + 0.7 * scale
            ah = 1.3 * scale
            aw = 2.2 * scale
            vec_poly = [
                (0.2 * scale, y_m - t * 0.5),
                (w - aw, y_m - t * 0.5),
                (w - aw, y_m - ah),
                (w, y_m),
                (w - aw, y_m + ah),
                (w - aw, y_m + t * 0.5),
                (0.2 * scale, y_m + t * 0.5),
            ]
            polys.append(vec_poly)
            return LayoutBox(width=w, ascent=y_m + ah + 0.3 * scale, descent=body.descent, polygons=polys)
        elif kind == "arc":
            eff_w = max(w, 4.0 * scale)
            if w >= 4.0 * scale:
                x_l = 0.4 * scale
                x_r = w - 0.4 * scale
            elif w > 0:
                x_l = w * 0.08
                x_r = w * 0.92
            else:
                x_l = 0.2 * scale
                x_r = eff_w - 0.2 * scale
            arc_h = 2.0 * scale
            peak_y = y_base + arc_h
            arc_pts_top = []
            arc_pts_bot = []
            n_steps = 14
            for step in range(n_steps + 1):
                u = step / float(n_steps)
                px = x_l + u * (x_r - x_l)
                ang = u * math.pi
                curve = math.sin(ang)
                py_top = y_base + arc_h * curve
                thick = t * (0.6 + 0.4 * curve)
                py_bot = py_top - thick
                arc_pts_top.append((px, py_top))
                arc_pts_bot.append((px, py_bot))
            arc_poly = arc_pts_top + list(reversed(arc_pts_bot))
            polys.append(arc_poly)
            return LayoutBox(
                width=max(w, eff_w),
                ascent=peak_y + 0.3 * scale,
                descent=body.descent,
                polygons=polys,
            )
        return body

    def _build_fence(self, ld: str, rd: str, bm: bytes, bb: LayoutBox, scale: float) -> tuple[bytes, LayoutBox]:
        # Determine MTEF selector & variation
        has_l = ld not in (".", "")
        has_r = rd not in (".", "")
        var = (1 if has_l else 0) | (2 if has_r else 0)

        if "{" in (ld, rd) or r"\{" in (ld, rd):
            sel, lch, rch = 2, 0x7B, 0x7D
        elif "[" in (ld, rd):
            sel, lch, rch = 3, 0x5B, 0x5D
        elif "|" in (ld, rd):
            sel, lch, rch = 4, 0x7C, 0x7C
        else:
            sel, lch, rch = 1, 0x28, 0x29

        fence_chars = b""
        if has_l:
            fence_chars += struct.pack("<BBBH", 2, 0, 0x96, lch)
        if has_r:
            fence_chars += struct.pack("<BBBH", 2, 0, 0x96, rch)

        mtef = struct.pack("<BBBBB", 3, 0, sel, var, 0) + b"\x01\x00" + bm + b"\x00" + fence_chars + b"\x00"
        return mtef, self._layout_fenced_box(ld, rd, bb, scale)

    def _layout_fenced_box(self, ld: str, rd: str, inner: LayoutBox, scale: float) -> LayoutBox:
        axis = 3.2 * scale
        half_h = max(inner.ascent - axis, axis + inner.descent, 4.5 * scale) + 0.8 * scale
        top_y = axis + half_h
        bot_y = axis - half_h
        h = top_y - bot_y

        fw = 3.4 * scale
        t = 0.65 * scale
        has_l = ld not in (".", "")
        has_r = rd not in (".", "")

        polys = []
        cur_x = 0.0
        if has_l:
            polys.append(self._draw_delim_poly(ld, cur_x, bot_y, top_y, fw, t, is_left=True))
            cur_x += fw + 0.6 * scale

        for p in inner.polygons:
            polys.append([(x + cur_x, y) for (x, y) in p])
        cur_x += inner.width

        if has_r:
            cur_x += 0.6 * scale
            polys.append(self._draw_delim_poly(rd, cur_x, bot_y, top_y, fw, t, is_left=False))
            cur_x += fw

        return LayoutBox(width=cur_x, ascent=top_y, descent=max(0.5 * scale, -bot_y), polygons=polys)

    def _draw_delim_poly(
        self, delim: str, x0: float, bot_y: float, top_y: float, fw: float, t: float, is_left: bool
    ) -> list[tuple[float, float]]:
        mid_y = (bot_y + top_y) * 0.5
        if "|" in delim:
            cx = x0 + fw * 0.5
            return self._rect_poly(cx - t * 0.5, bot_y, cx + t * 0.5, top_y)
        if "[" in delim or "]" in delim:
            if is_left:
                return [
                    (x0 + fw * 0.2, bot_y),
                    (x0 + fw * 0.85, bot_y),
                    (x0 + fw * 0.85, bot_y + t),
                    (x0 + fw * 0.2 + t, bot_y + t),
                    (x0 + fw * 0.2 + t, top_y - t),
                    (x0 + fw * 0.85, top_y - t),
                    (x0 + fw * 0.85, top_y),
                    (x0 + fw * 0.2, top_y),
                ]
            else:
                return [
                    (x0 + fw * 0.15, bot_y),
                    (x0 + fw * 0.8, bot_y),
                    (x0 + fw * 0.8, top_y),
                    (x0 + fw * 0.15, top_y),
                    (x0 + fw * 0.15, top_y - t),
                    (x0 + fw * 0.8 - t, top_y - t),
                    (x0 + fw * 0.8 - t, bot_y + t),
                    (x0 + fw * 0.15, bot_y + t),
                ]
        if "{" in delim or "}" in delim:
            # Smooth curly brace polygon
            cx = x0 + fw * 0.5
            tip_x = x0 + (fw * 0.15 if is_left else fw * 0.85)
            end_x = x0 + (fw * 0.85 if is_left else fw * 0.15)
            s = 1.0 if is_left else -1.0
            return [
                (end_x, top_y),
                (cx, top_y - t * 0.5),
                (cx, mid_y + t),
                (tip_x, mid_y),
                (cx, mid_y - t),
                (cx, bot_y + t * 0.5),
                (end_x, bot_y),
                (end_x, bot_y + t * 0.8),
                (cx + s * t, bot_y + t * 1.2),
                (cx + s * t, mid_y - t * 0.8),
                (tip_x + s * t * 1.1, mid_y),
                (cx + s * t, mid_y + t * 0.8),
                (cx + s * t, top_y - t * 1.2),
                (end_x, top_y - t * 0.8),
            ]
        # Default: smooth curved parenthesis arc
        steps = 12
        outer = []
        inner = []
        for i in range(steps + 1):
            u = i / steps  # 0 (bottom) to 1 (top)
            ang = (u - 0.5) * math.pi
            curve = math.cos(ang)  # 0 at ends, 1 at middle
            y = bot_y + u * (top_y - bot_y)
            if is_left:
                ox = x0 + fw * 0.85 - curve * (fw * 0.65)
                ix = ox + t * (0.4 + 0.7 * curve)
            else:
                ox = x0 + fw * 0.15 + curve * (fw * 0.65)
                ix = ox - t * (0.4 + 0.7 * curve)
            outer.append((ox, y))
            inner.append((ix, y))
        return outer + list(reversed(inner))

    def _layout_pile(self, rows: list[LayoutBox], scale: float) -> LayoutBox:
        if not rows:
            return LayoutBox(width=4.0 * scale, ascent=8.0 * scale, descent=0.5 * scale, polygons=[])
        row_gap = 3.2 * scale
        total_h = sum(r.ascent + r.descent for r in rows) + row_gap * (len(rows) - 1)
        max_w = max(r.width for r in rows)
        axis = 3.2 * scale
        top_y = axis + total_h * 0.5
        bot_y = axis - total_h * 0.5

        polys = []
        cur_top = top_y
        for r in rows:
            ry = cur_top - r.ascent
            for p in r.polygons:
                polys.append([(x, y + ry) for (x, y) in p])
            cur_top -= r.ascent + r.descent + row_gap

        return LayoutBox(width=max_w, ascent=top_y, descent=max(0.5 * scale, -bot_y), polygons=polys)
