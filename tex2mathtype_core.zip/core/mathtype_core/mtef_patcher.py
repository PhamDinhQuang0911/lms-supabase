# -*- coding: utf-8 -*-
"""
mtef_patcher.py

Patch MTEF v3 từ LibreOffice để thay overline+U+200E (LRM marker cho arc)
bằng FROWN template (0x22) + font MT Extra.

Luồng:
  1. LO render full formula với \overline{LRM base} cho arc
  2. LO xuất MTEF v3 (có overline template)
  3. Hàm patch_mtef_arc() tìm overline+LRM → thay bằng FROWN + MT Extra
  4. Kết quả: MathType kích đúp được, cung là MT Extra thật

Usage:
    from .mtef_patcher import patch_mtef_arc
    patched = patch_mtef_arc(lo_mtef_bytes)
    # => MTEF v5 với FROWN thay vì overline
"""

import struct
import re

# MTEF constants
MTEF_V3_HEADER_SIZE = 28

# Font indices trong MTEF
# LO thường dùng: 0=Times, 1=Symbol, 2=Courier
# Ta thêm MT Extra ở index 3 (hoặc tìm index phù hợp)
FONT_MT_EXTRA_NAME = b"MT Extra"

# Template types
T_OVERLINE = 0x08
T_FROWN = 0x22

# LRM marker (U+200E) - dùng để đánh dấu arc trong StarMath
LRM_BYTE = b'\x20\x0E'  # UTF-16LE

# FROWN glyph trong MT Extra (U+2322)
FROWN_GLYPH = b'\x22\x23'  # UTF-16LE: U+2322


def _find_mtef_font_table_end(data: bytes, start: int = 28) -> int:
    """Tìm vị trí kết thúc font table trong MTEF.
    
    Font table kết thúc bằng 0x12 0x00.
    """
    i = start
    while i < len(data) - 1:
        if data[i] == 0x12 and data[i+1] == 0x00:
            return i + 2
        i += 1
    return start  # fallback


def _has_mt_extra_font(data: bytes) -> bool:
    """Kiểm tra MTEF đã có font MT Extra chưa."""
    return FONT_MT_EXTRA_NAME in data


def _add_mt_extra_font(mtef: bytearray, font_table_end: int) -> int:
    """Thêm font definition MT Extra vào font table.
    
    Returns: vị trí mới của font_table_end.
    """
    # Font entry: 0x11 len name  (name không null-terminated trong LO MTEF)
    entry = bytearray()
    entry.append(0x11)
    entry.append(len(FONT_MT_EXTRA_NAME))
    entry.extend(FONT_MT_EXTRA_NAME)
    
    # Chèn vào trước 0x12 0x00
    mtef[font_table_end:font_table_end] = entry
    return font_table_end + len(entry)


def _find_overline_with_lrm(mtef: bytes, start: int) -> int:
    """Tìm overline template (0x08) chứa LRM (U+200E) trong MTEF.
    
    Returns: offset của template header, hoặc -1 nếu không tìm thấy.
    """
    i = start
    while i < len(mtef) - 4:
        # Tìm TMPL header với type=0x08 (overline)
        if mtef[i] == 0x03 and mtef[i+2] == T_OVERLINE:
            # Kiểm tra trong slot có LRM không
            slot_start = i + 7  # sau TMPL header 7 byte
            # Tìm LRM trong slot
            for j in range(slot_start, min(slot_start + 20, len(mtef))):
                if mtef[j:j+2] == LRM_BYTE:
                    return i
            i += 1
        else:
            i += 1
    return -1


def _find_overline_with_lrm_v3(mtef: bytes, start: int) -> int:
    """Tìm overline trong MTEF v3 (cấu trúc khác v5).
    
    MTEF v3 không có TMPL header 7 byte như v5.
    Overline trong v3 là 0x08 (single byte template type).
    
    Returns: offset của overline byte, hoặc -1.
    """
    i = start
    while i < len(mtef) - 2:
        if mtef[i] == T_OVERLINE:
            # Kiểm tra xung quanh có LRM không
            for j in range(max(0, i-10), min(len(mtef), i+30)):
                if mtef[j:j+2] == LRM_BYTE:
                    return i
            i += 1
        else:
            i += 1
    return -1


def _find_lrm_position(mtef: bytes, start: int, end: int) -> int:
    """Tìm vị trí của LRM (U+200E) trong khoảng [start, end)."""
    for i in range(start, min(end, len(mtef) - 1)):
        if mtef[i:i+2] == LRM_BYTE:
            return i
    return -1


def patch_mtef_arc(mtef_bytes: bytes) -> bytes:
    """Patch MTEF từ LO: thay overline+LRM → FROWN + MT Extra.
    
    Input: MTEF v3 từ LibreOffice (có \overline{LRM base} cho arc)
    Output: MTEF v5-like với FROWN template và font MT Extra
    
    Quy trình:
    1. Thêm font MT Extra vào font table (nếu chưa có)
    2. Tìm overline template chứa LRM
    3. Thay overline → FROWN template
    4. Thay glyph → U+2322 font MT Extra
    """
    if not mtef_bytes or len(mtef_bytes) < 32:
        return mtef_bytes
    
    mtef = bytearray(mtef_bytes)
    
    # Bước 1: Thêm MT Extra font
    font_end = _find_mtef_font_table_end(mtef)
    mt_extra_idx = None
    
    if not _has_mt_extra_font(mtef):
        mt_extra_idx = _add_mt_extra_font(mtef, font_end)
        # Cập nhật font count trong header (offset 28)
        # Font count ở offset 28 (2 bytes LE)
        if len(mtef) > 30:
            font_count = struct.unpack_from('<H', mtef, 28)[0]
            font_count += 1
            struct.pack_into('<H', mtef, 28, font_count)
    else:
        # Tìm index của MT Extra
        i = 28
        idx = 0
        while i < len(mtef) - 2:
            if mtef[i] == 0x11:
                name_len = mtef[i+1]
                name = mtef[i+2:i+2+name_len]
                if name == FONT_MT_EXTRA_NAME:
                    mt_extra_idx = idx
                    break
                idx += 1
                i += 2 + name_len
            elif mtef[i] == 0x12 and mtef[i+1] == 0x00:
                break
            else:
                i += 1
    
    if mt_extra_idx is None:
        # MT Extra vừa được thêm, index = font_count - 1
        font_count = struct.unpack_from('<H', mtef, 28)[0]
        mt_extra_idx = font_count - 1
    
    # Bước 2: Tìm và patch overline+LRM → FROWN+MT Extra
    # Thử cả v3 và v5 format
    pos = _find_overline_with_lrm(mtef, 28)
    
    if pos >= 0:
        # MTEF v5 format: 03 00 08 00 00 NN 00 ...
        # Thay type từ 0x08 → 0x22
        mtef[pos + 2] = T_FROWN
        
        # Tìm LRM trong slot và thay bằng FROWN glyph với MT Extra font
        slot_start = pos + 7
        lrm_pos = _find_lrm_position(mtef, slot_start, len(mtef))
        if lrm_pos >= 0:
            # CHAR record cho LRM: 02 00 tf lo hi
            # Thay bằng CHAR với MT Extra font
            # tf byte là byte thứ 3 của CHAR record (offset lrm_pos+2)
            if lrm_pos + 4 < len(mtef):
                # Xác định typeface byte cho MT Extra
                # Trong MTEF, typeface = 0x80 + font_index
                tf_byte = 0x80 + mt_extra_idx
                mtef[lrm_pos + 2] = tf_byte
                # Glyph: U+2322 FROWN
                mtef[lrm_pos] = 0x22  # lo byte
                mtef[lrm_pos + 1] = 0x23  # hi byte
    
    else:
        # Thử MTEF v3 format
        pos = _find_overline_with_lrm_v3(mtef, 28)
        if pos >= 0:
            # V3: overline là 0x08, thay bằng 0x22 (FROWN)
            mtef[pos] = T_FROWN
            
            # Tìm LRM gần đó
            lrm_pos = _find_lrm_position(mtef, max(0, pos-10), min(len(mtef), pos+30))
            if lrm_pos >= 0:
                tf_byte = 0x80 + mt_extra_idx
                if lrm_pos + 2 < len(mtef):
                    mtef[lrm_pos + 2] = tf_byte
                mtef[lrm_pos] = 0x22
                mtef[lrm_pos + 1] = 0x23
    
    # Bước 3: Cập nhật size trong header
    # Header byte 8-11: size của payload (sau 28-byte header)
    payload_size = len(mtef) - 28
    struct.pack_into('<I', mtef, 8, payload_size)
    
    return bytes(mtef)


def patch_ole_mtef_arc(ole_bytes: bytes) -> bytes:
    """Patch OLE compound file: thay Equation Native bằng MTEF đã patch.
    
    Input: OLE bytes từ LO (có Equation Native stream)
    Output: OLE bytes với Equation Native đã patch FROWN+MT Extra
    """
    import olefile
    import io
    
    try:
        ole = olefile.OleFileIO(ole_bytes)
        eqn = ole.openstream('Equation Native').read()
        
        # Patch MTEF
        patched = patch_mtef_arc(eqn)
        
        # Xây lại OLE với Equation Native đã patch
        # Cần copy tất cả stream, chỉ thay Equation Native
        ole.close()
        
        # Dùng mathtype_ole_builder để tạo OLE mới với MTEF đã patch
        from .mathtype_ole_builder import make_mathtype_ole
        return make_mathtype_ole(patched)
        
    except Exception as e:
        print(f"patch_ole_mtef_arc error: {e}")
        return ole_bytes


# ──────────────────────────────────────────────
# Self-test
# ──────────────────────────────────────────────

def selftest():
    """Kiểm tra patch MTEF với dữ liệu mẫu."""
    print("=" * 60)
    print("MTEF PATCHER SELFTEST")
    print("=" * 60)
    
    # Test 1: Tạo MTEF v3 mẫu có overline+LRM
    print("\n--- Test 1: Patch MTEF v3 with overline+LRM ---")
    
    # Tạo MTEF v3 đơn giản: font table + overline{LRM AB}
    # Đây là cấu trúc MTEF v3 tối thiểu
    sample = bytearray()
    
    # Header (28 bytes)
    sample.extend(struct.pack('<I', 0))  # size (sẽ update sau)
    sample.extend(b'\x02\x00\x7d\xc2')  # version + platform
    sample.extend(b'\x00' * 20)  # padding
    
    # Font table
    sample.extend(b'\x05\x01\x00\x07\x08\x44\x53\x4d\x54\x37')  # DSMT7
    sample.extend(b'\x01\x13WinAllBasicCodePages')  # codepage
    sample.extend(b'\x11\x05Times')  # font 0: Times
    sample.extend(b'\x11\x03Sym')    # font 1: Symbol
    sample.extend(b'\x11\x05Couri')  # font 2: Courier
    sample.extend(b'\x12\x00')       # end font table
    
    # Size/index block (tối thiểu)
    sample.extend(b'\x00' * 8)
    
    # Formula: overline{LRM AB}
    # Trong MTEF v3: overline = 0x08, theo sau là slot
    # CHAR: tag=02, opts=00, tf=00, lo, hi
    # LRM = U+200E
    sample.extend(b'\x08')  # overline
    sample.extend(b'\x02\x00\x00\x20\x0e')  # CHAR LRM
    sample.extend(b'\x02\x00\x00\x41\x00')  # CHAR A
    sample.extend(b'\x02\x00\x00\x42\x00')  # CHAR B
    sample.extend(b'\x00')  # end slot
    sample.extend(b'\x00')  # end expression
    
    # Update size
    payload_size = len(sample) - 28
    struct.pack_into('<I', sample, 8, payload_size)
    
    print(f"Sample MTEF: {len(sample)} bytes")
    print(f"  Has overline (0x08): {b'\\x08' in sample}")
    print(f"  Has LRM (U+200E): {LRM_BYTE in sample}")
    
    # Patch
    patched = patch_mtef_arc(bytes(sample))
    print(f"Patched MTEF: {len(patched)} bytes")
    print(f"  Has FROWN (0x22): {b'\\x22' in patched}")
    print(f"  Has MT Extra font: {_has_mt_extra_font(patched)}")
    
    # Verify
    has_frown = b'\x22' in patched
    has_mt_extra = _has_mt_extra_font(patched)
    
    if has_frown and has_mt_extra:
        print("  ✅ FROWN + MT Extra found!")
    else:
        print(f"  ⚠ FROWN={has_frown}, MT_Extra={has_mt_extra}")
    
    # Test 2: Patch với MTEF thật từ Doc3 (đã biết là đúng)
    print("\n--- Test 2: Verify Doc3 MTEF is NOT modified ---")
    import olefile
    try:
        ole = olefile.OleFileIO('Doc3.doc')
        doc3_mtef = ole.openstream('ObjectPool/_1846005202/Equation Native').read()
        ole.close()
        
        # Doc3 không có overline+LRM, nên patch không nên thay đổi gì
        patched_doc3 = patch_mtef_arc(doc3_mtef)
        
        if patched_doc3 == doc3_mtef:
            print("  ✅ Doc3 MTEF unchanged (no LRM to patch)")
        else:
            print(f"  ⚠ Doc3 changed: {len(doc3_mtef)} → {len(patched_doc3)} bytes")
            # Show differences
            for i in range(min(len(doc3_mtef), len(patched_doc3))):
                if doc3_mtef[i] != patched_doc3[i]:
                    print(f"  Diff at {i}: {doc3_mtef[i]:02x} → {patched_doc3[i]:02x}")
                    break
    except Exception as e:
        print(f"  ⚠ Doc3 test skipped: {e}")
    
    print("\n✅ Selftest complete!")


if __name__ == "__main__":
    selftest()
