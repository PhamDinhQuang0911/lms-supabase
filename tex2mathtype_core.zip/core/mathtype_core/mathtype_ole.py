r"""
mathtype_ole.py  (đã sửa lỗi)
Thư viện tạo công thức toán dạng OLE MathType THẬT (định dạng "Equation.3" /
MTEF - Microsoft Equation Editor / MathType) trong file Word .doc, xuất phát
từ mã LaTeX — KHÔNG cần cài MathType.

CÁCH HOẠT ĐỘNG:
  Luồng xử lý: LaTeX --(latex_to_starmath.convert)--> StarMath
               --(LibreOffice UNO API)--> đối tượng OLE "Equation.3" thật
               --> nhúng vào file .doc

LƯU Ý: Phải lưu ra .doc (Word 97), KHÔNG phải .docx, để giữ OLE MathType thật.
"""

import glob
import os
import subprocess
import time

from .latex_to_starmath import convert as latex_to_starmath


def _prop(name, value):
    from com.sun.star.beans import PropertyValue
    p = PropertyValue()
    p.Name = name
    p.Value = value
    return p


def _find_soffice() -> str:
    """Tự động tìm đường dẫn soffice.exe trên Windows (không hard-code)."""
    import platform
    if platform.system() != "Windows":
        return "soffice"  # Linux/macOS: dùng PATH

    # Các vị trí thường gặp
    candidates = [
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]
    # Tìm thêm qua registry hoặc glob ổ D, E
    for drive in ["D", "E", "F"]:
        candidates += glob.glob(rf"{drive}:\*\LibreOffice*\program\soffice.exe")
        candidates += glob.glob(rf"{drive}:\Program Files*\LibreOffice*\program\soffice.exe")

    # Tìm qua registry
    try:
        import winreg
        for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                key = winreg.OpenKey(root, r"SOFTWARE\LibreOffice\UNO\InstallPath")
                path, _ = winreg.QueryValueEx(key, "")
                candidates.insert(0, os.path.join(path, "..", "program", "soffice.exe"))
            except Exception:
                pass
    except ImportError:
        pass

    for c in candidates:
        c = os.path.normpath(c)
        if os.path.isfile(c):
            return c

    raise FileNotFoundError(
        "Không tìm thấy LibreOffice. Hãy cài LibreOffice từ https://www.libreoffice.org/\n"
        "hoặc kiểm tra lại đường dẫn cài đặt."
    )


class MathTypeWriter:
    """Kết nối tới LibreOffice đang chạy nền và tạo file .doc chứa các công
    thức OLE MathType thật, dịch trực tiếp từ LaTeX."""

    MATH_CLSID = "078B7ABA-54FC-457F-8551-6147e776a997"

    def __init__(self, host="localhost", port=2002, start_if_needed=True,
                 logger=None):
        self.host = host
        self.port = port
        self.logger = logger or (lambda x: None)
        self.desktop = None

        if start_if_needed:
            if self._try_connect():
                self.logger("Đã kết nối LibreOffice sẵn có.")
            else:
                self.logger("LibreOffice chưa chạy, đang khởi động...")
                self._kill_stale_soffice()
                self._start_soffice()
                # _start_soffice đã gọi _connect() bên trong khi thành công
        else:
            self._connect()

    # ------------------------------------------------------------------
    # Kết nối UNO
    # ------------------------------------------------------------------

    def _try_connect(self) -> bool:
        try:
            self._connect()
            return True
        except Exception:
            return False

    def _connect(self):
        """Kết nối UNO — raise nếu thất bại."""
        import uno
        local_ctx = uno.getComponentContext()
        resolver = local_ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.bridge.UnoUrlResolver", local_ctx)
        ctx = resolver.resolve(
            f"uno:socket,host={self.host},port={self.port};urp;"
            "StarOffice.ComponentContext")
        smgr = ctx.ServiceManager
        self.desktop = smgr.createInstanceWithContext(
            "com.sun.star.frame.Desktop", ctx)

    # ------------------------------------------------------------------
    # Quản lý tiến trình LibreOffice
    # ------------------------------------------------------------------

    def _kill_stale_soffice(self):
        """Kill các tiến trình soffice cũ để giải phóng port."""
        import platform
        if platform.system() != "Windows":
            return
        try:
            flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0x08000000
            subprocess.run(["taskkill", "/F", "/IM", "soffice.bin", "/T"],
                           capture_output=True, timeout=10, creationflags=flags)
            subprocess.run(["taskkill", "/F", "/IM", "soffice.exe", "/T"],
                           capture_output=True, timeout=10, creationflags=flags)
            time.sleep(2)
            self.logger("Đã dọn sạch tiến trình LibreOffice cũ.")
        except Exception as e:
            self.logger(f"Cảnh báo kill soffice: {e}")

    def _start_soffice(self):
        """Khởi động LibreOffice headless và chờ kết nối thành công."""
        import platform
        try:
            soffice = _find_soffice()
        except FileNotFoundError as e:
            raise RuntimeError(str(e))

        self.logger(f"Đang khởi động LibreOffice: {soffice}")

        if platform.system() == "Windows":
            cmd = [soffice]
        else:
            cmd = ["setsid", soffice]

        cmd += [
            "--headless", "--invisible",
            "--nocrashreport", "--nodefault", "--norestore",
            "--nologo", "--nofirststartwizard",
            f"--accept=socket,host={self.host},port={self.port};urp;",
        ]

        flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0x08000000
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)

        # Chờ tối đa 45 giây, log tiến trình mỗi 5 giây
        wait_total = 45
        for elapsed in range(wait_total):
            time.sleep(1)
            if self._try_connect():
                self.logger(f"LibreOffice đã sẵn sàng (sau {elapsed + 1}s).")
                return
            if elapsed % 5 == 4:
                self.logger(f"Đang chờ LibreOffice khởi động... ({elapsed + 1}/{wait_total}s)")

        raise RuntimeError(
            "Không thể khởi động LibreOffice sau 45 giây.\n"
            "Thử: (1) Mở Task Manager, tắt hết soffice.exe; (2) Chạy lại tool."
        )

    def restart(self):
        """Kill LibreOffice và khởi động lại — dùng khi bridge bị hỏng."""
        self.logger("Đang khởi động lại LibreOffice...")
        self._kill_stale_soffice()
        self._start_soffice()

    # ------------------------------------------------------------------
    # Build document
    # ------------------------------------------------------------------

    def build_doc(self, equations, output_path, titles=None):
        """equations: list các chuỗi LaTeX.
        titles: (tuỳ chọn) list nhãn hiển thị phía trên mỗi công thức.
        output_path: đường dẫn file .doc đầu ra."""
        import uno
        doc = self.desktop.loadComponentFromURL(
            "private:factory/swriter", "_blank", 0, (_prop("Hidden", True),))
        text = doc.getText()
        cursor = text.createTextCursor()

        for idx, latex in enumerate(equations):
            starmath = latex_to_starmath(latex)

            if titles:
                text.insertString(cursor, titles[idx], False)
                text.insertControlCharacter(
                    cursor,
                    uno.getConstantByName(
                        "com.sun.star.text.ControlCharacter.LINE_BREAK"),
                    False)

            ole_obj = doc.createInstance(
                "com.sun.star.text.TextEmbeddedObject")
            ole_obj.CLSID = self.MATH_CLSID
            text.insertTextContent(cursor, ole_obj, False)

            embedded = ole_obj.EmbeddedObject
            embedded.changeState(1)  # EmbedStates.RUNNING
            component = embedded.getComponent()
            component.Formula = starmath
            try:
                component.IsTextMode = False
            except Exception:
                pass
            component.store()

            text.insertControlCharacter(
                cursor,
                uno.getConstantByName(
                    "com.sun.star.text.ControlCharacter.PARAGRAPH_BREAK"),
                False)

        doc.storeToURL(
            uno.systemPathToFileUrl(output_path),
            (_prop("FilterName", "MS Word 97"),))
        doc.close(False)
        return output_path

    def close(self):
        pass


# ---------------------------------------------------------------------------
# Hàm tiện ích
# ---------------------------------------------------------------------------

def latex_list_to_mathtype_doc(equations, output_path, titles=None,
                                host="localhost", port=2002, logger=None):
    """Hàm tiện ích một bước: đưa vào danh sách công thức LaTeX, nhận về
    đường dẫn file .doc chứa các công thức đó dưới dạng OLE MathType thật."""
    writer = MathTypeWriter(host=host, port=port, logger=logger)
    return writer.build_doc(equations, output_path, titles=titles)


if __name__ == "__main__":
    demo_equations = [
        r"\frac{-b \pm \sqrt{b^2 - 4ac}}{2a}",
        r"\sum_{i=1}^{n} i = \frac{n(n+1)}{2}",
        r"\int_{a}^{b} f(x)\,dx = F(b) - F(a)",
        r"\lim_{x \to 0} \frac{\sin x}{x} = 1",
        r"e^{i\pi} + 1 = 0",
    ]
    demo_titles = [
        "Phương trình bậc hai:",
        "Tổng cấp số cộng:",
        "Tích phân Newton-Leibniz:",
        "Giới hạn cơ bản:",
        "Đẳng thức Euler:",
    ]
    out = latex_list_to_mathtype_doc(
        demo_equations,
        os.path.join(os.path.dirname(__file__), "demo_mathtype.doc"),
        titles=demo_titles,
        logger=print,
    )
    print("Đã tạo:", out)
