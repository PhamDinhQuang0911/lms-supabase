"""
converter_engine.py - Bộ điều phối chuyển đổi toàn diện TeX / DOC / DOCX sang Word MathType OLE.
Hoàn toàn độc lập, tạo file Word nền trắng (không header, không footer, không background).
"""

import os
import sys
import re
import shutil
import tempfile
import traceback
from typing import List, Callable, Optional, Dict

from .tex_normalizer import (
    strip_preamble,
    replace_section_titles,
    break_immini,
    replace_math_systems,
    format_solutions,
    remove_solutions,
    replace_shortans_commands,
    replace_double_slash,
    replace_ex_and_lists,
    replace_choice_commands,
    clean_true_commands,
    compile_tikz_blocks_to_png,
    build_blank_skeleton_docx,
    WORD_STANDARDS
)
from .docx_extractor import (
    convert_doc_to_docx,
    extract_text_and_questions_from_docx
)
from .mathtype_core import docx_processor


class TeXToMathTypeConverter:
    """Bộ chuyển đổi TeX / DOC / DOCX sang Word MathType OLE độc lập."""

    def __init__(self,
                 word_standard: str = 'btn_group',
                 use_libreoffice: bool = True,
                 lo_threads: int = 4,
                 base_pt: float = 11.0):
        self.word_standard = word_standard
        self.use_libreoffice = use_libreoffice
        self.lo_threads = lo_threads
        self.base_pt = base_pt

    def convert_file(self,
                     input_file: str,
                     output_dir: Optional[str] = None,
                     export_mode: str = 'both',
                     docx_mode: str = 'standardize',
                     progress_callback: Optional[Callable[[int, str], None]] = None,
                     log_callback: Optional[Callable[[str], None]] = None) -> List[str]:
        """
        Chuyển đổi 1 file duy nhất (.tex, .docx, .doc) sang Word MathType.
        
        Args:
            input_file: Đường dẫn file nguồn
            output_dir: Thư mục lưu kết quả (nếu None sẽ lưu cùng thư mục với file nguồn)
            export_mode: 'both' (2 file), 'questions' (chỉ đề bài), 'full' (bản đầy đủ có lời giải)
            docx_mode: 'standardize' (chuẩn hóa toàn bộ cấu trúc) hoặc 'inplace' (chuyển công thức tại chỗ)
            progress_callback: Hàm nhận (phần_trăm, thông_báo)
            log_callback: Hàm nhận log dạng text
        Returns:
            Danh sách các đường dẫn file .docx đã tạo thành công
        """
        def log(msg: str):
            if log_callback:
                try: log_callback(msg)
                except Exception: pass
            try:
                print(f"[CONVERTER] {msg}")
            except Exception:
                pass

        def prog(pct: int, msg: str):
            if progress_callback:
                try: progress_callback(pct, msg)
                except Exception: pass

        if not os.path.exists(input_file):
            raise FileNotFoundError(f"Không tìm thấy file nguồn: {input_file}")

        if not output_dir:
            output_dir = os.path.dirname(os.path.abspath(input_file))
        os.makedirs(output_dir, exist_ok=True)

        base_name = os.path.splitext(os.path.basename(input_file))[0]
        ext = os.path.splitext(input_file)[1].lower()

        log(f"Bắt đầu xử lý: {os.path.basename(input_file)} (Chế độ: {export_mode}, Chuẩn: {self.word_standard})")
        prog(10, f"Đang chuẩn bị file: {os.path.basename(input_file)}...")

        temp_dir = tempfile.mkdtemp(prefix="tex2mt_")
        created_files = []

        try:
            # ────────────────────────────────────────────────────────
            # 1. TRƯỜNG HỢP FILE .DOCX / .DOC VỚI CHẾ ĐỘ INPLACE (GIỮ NGUYÊN BỐ CỤC & HÌNH VẼ)
            # ────────────────────────────────────────────────────────
            if ext in ['.docx', '.doc'] and docx_mode == 'inplace':
                working_file = input_file
                if ext == '.doc':
                    log("Phát hiện file .doc cũ. Đang tự động chuyển sang .docx qua LibreOffice...")
                    prog(15, "Đang chuyển đổi .doc sang .docx...")
                    working_file = convert_doc_to_docx(input_file, temp_dir)

                log("Đang chuyển đổi công thức trực tiếp tại chỗ trên file Word gốc (bảo toàn 100% hình vẽ & bố cục)...")
                target_out = os.path.join(output_dir, f"{base_name}_MathType.docx")
                prog(40, "Đang quét và chuyển đổi công thức LaTeX sang MathType OLE...")
                
                def pcb(curr, tot, eq_str):
                    sub_pct = 40 + int((curr / max(1, tot)) * 50)
                    prog(sub_pct, f"Chuyển đổi công thức {curr}/{tot}: {str(eq_str)[:30]}...")

                r = docx_processor.convert_docx_latex_to_mathtype(
                    input_path=working_file,
                    output_path=target_out,
                    use_libreoffice=self.use_libreoffice,
                    progress_callback=pcb,
                    lo_threads=self.lo_threads,
                    base_pt=self.base_pt
                )
                log(f"Hoàn tất file: {target_out}")
                created_files.append(target_out)
                prog(100, "Hoàn tất chuyển đổi!")
                return created_files

            # ────────────────────────────────────────────────────────
            # 2. XỬ LÝ ĐỌC NỘI DUNG VÀO DẠNG LATEX TEXT (TRÍCH XUẤT CẢ HÌNH VẼ)
            # ────────────────────────────────────────────────────────
            raw_text = ""
            if ext == '.doc':
                log("Phát hiện file .doc cũ. Đang tự động chuyển sang .docx qua LibreOffice...")
                prog(15, "Đang chuyển đổi .doc sang .docx...")
                converted_docx = convert_doc_to_docx(input_file, temp_dir)
                log("Đang trích xuất câu hỏi, công thức và bảo toàn toàn bộ hình vẽ minh họa từ file docx...")
                raw_text = extract_text_and_questions_from_docx(converted_docx, media_output_dir=temp_dir)
            elif ext == '.docx':
                log("Đang trích xuất câu hỏi, công thức và bảo toàn toàn bộ hình vẽ minh họa từ file .docx...")
                prog(15, "Đang phân tích cấu trúc đề thi Word và trích xuất hình ảnh...")
                raw_text = extract_text_and_questions_from_docx(input_file, media_output_dir=temp_dir)
            else: # .tex
                log("Đang đọc file mã nguồn LaTeX (.tex)...")
                prog(15, "Đang đọc file .tex...")
                encodings = ['utf-8', 'utf-8-sig', 'utf-16', 'cp1258', 'latin-1']
                read_ok = False
                for enc in encodings:
                    try:
                        with open(input_file, 'r', encoding=enc) as f:
                            raw_text = f.read()
                        read_ok = True
                        break
                    except Exception:
                        continue
                if not read_ok:
                    raise UnicodeDecodeError(f"Không thể đọc mã hóa file '{input_file}'!")

            # ────────────────────────────────────────────────────────
            # 3. TIỀN XỬ LÝ CHUẨN HÓA LATEX TEXT
            # ────────────────────────────────────────────────────────
            log("Tiến hành tiền xử lý, gỡ bỏ preamble và chuẩn hóa cấu trúc...")
            prog(22, "Gỡ bỏ cấu trúc thừa và tiền xử lý môi trường...")
            raw_text = strip_preamble(raw_text)

            # 3.1 Trích xuất và biên dịch khối TiKZ sang ảnh PNG phân giải cao
            tikz_pattern = re.compile(r'\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}', re.DOTALL)
            tikz_blocks = tikz_pattern.findall(raw_text)
            if tikz_blocks:
                log(f"Phát hiện {len(tikz_blocks)} hình vẽ TiKZ. Đang tự động biên dịch sang ảnh PNG phân giải cao...")
                prog(25, f"Đang render {len(tikz_blocks)} hình vẽ TiKZ...")
                try:
                    compile_tikz_blocks_to_png(tikz_blocks, temp_dir, log)
                except Exception as te:
                    log(f"⚠️ Cảnh báo render TiKZ: {te}")
                for tz_i, tzb in enumerate(tikz_blocks, 1):
                    raw_text = raw_text.replace(tzb, f'[[TIKZ_IMG_{tz_i}]]', 1)

            # 3.2 Trích xuất các bảng tabular để chèn chuẩn Table Grid
            tabular_blocks = re.findall(r'\\begin\{tabular\}.*?\\end\{tabular\}', raw_text, re.DOTALL)
            for t_i, tb in enumerate(tabular_blocks):
                raw_text = raw_text.replace(tb, f'[[TABULAR_{t_i}]]', 1)

            raw_text = break_immini(raw_text)
            raw_text = replace_math_systems(raw_text)

            # Xác định các tác vụ xuất file
            tasks = []
            if export_mode == 'both':
                tasks = [
                    ('questions', os.path.join(output_dir, f"{base_name}_De_Bai.docx")),
                    ('full', os.path.join(output_dir, f"{base_name}_De_Va_Loi_Giai.docx"))
                ]
            elif export_mode == 'questions':
                tasks = [('questions', os.path.join(output_dir, f"{base_name}_De_Bai.docx"))]
            else:
                tasks = [('full', os.path.join(output_dir, f"{base_name}_De_Va_Loi_Giai.docx"))]

            total_tasks = len(tasks)
            for t_idx, (mode_name, out_path) in enumerate(tasks, 1):
                task_label = "Đề bài" if mode_name == 'questions' else "Đề bài & Lời giải"
                log(f"[{t_idx}/{total_tasks}] Chuẩn hóa và tạo tài liệu ({task_label})...")
                base_pct = 30 + (t_idx - 1) * 35

                pt = raw_text
                # Xóa các lệnh điều khiển LaTeX không cần thiết trong Word
                pt = re.sub(r'\\Opensolutionfile\s*\{.*?\}(\s*\[.*?\])?', '', pt)
                pt = re.sub(r'\\Closesolutionfile\s*\{.*?\}', '', pt)
                pt = re.sub(r'\\indapan\s*\{.*?\}\s*\{.*?\}\s*\{.*?\}', '', pt)
                pt = re.sub(r'\[ans/.*?\]', '', pt)
                pt = re.sub(r'\\(vspace|hspace|vskip|hskip)\*?\{[^}]*\}', '', pt)
                pt = re.sub(r'\\(newpage|clearpage|cleardoublepage|pagebreak)\b', '', pt)
                pt = re.sub(r'\\(label|ref|eqref|cite|index)\{[^}]*\}', '', pt)
                pt = re.sub(r'\\noindent\b', '', pt)
                pt = re.sub(r'\\par\b', '\n', pt)

                if mode_name == 'questions':
                    pt = remove_solutions(pt)
                    pt = replace_shortans_commands(pt, 'questions')
                else:
                    pt = format_solutions(pt)
                    pt = re.sub(r'\\begin\{loigiai\}', r'\n\n\\textbf{Lời giải:}\n\n', pt)
                    pt = re.sub(r'\\end\{loigiai\}', '\n\n', pt)
                    pt = replace_shortans_commands(pt, 'full')

                pt = replace_ex_and_lists(pt)
                pt = replace_choice_commands(pt, mode_name, word_standard=self.word_standard)
                # Xử lý triệt để lệnh \True theo đúng chế độ xuất
                pt = clean_true_commands(pt, mode_name)
                pt = replace_double_slash(pt)

                prog(base_pct + 5, f"[{task_label}] Đang tạo khung Word nền trắng (không header/footer)...")
                input_dir = os.path.dirname(os.path.abspath(input_file)) if os.path.exists(input_file) else ""
                skeleton_doc = build_blank_skeleton_docx(
                    processed_text=pt,
                    word_standard=self.word_standard,
                    temp_img_dir=temp_dir,
                    tabular_blocks=tabular_blocks,
                    input_dir=input_dir
                )
                
                temp_sk_path = os.path.join(temp_dir, f"skeleton_{mode_name}.docx")
                skeleton_doc.save(temp_sk_path)

                log(f"[{task_label}] Bắt đầu chuyển đổi công thức toán sang MathType OLE...")
                prog(base_pct + 15, f"[{task_label}] Chuyển đổi công thức LaTeX sang MathType OLE...")

                def make_pcb(b_pct):
                    def pcb(curr, tot, eq_str):
                        calc_pct = b_pct + 15 + int((curr / max(1, tot)) * 18)
                        prog(min(98, calc_pct), f"[{task_label}] CT {curr}/{tot}: {str(eq_str)[:25]}...")
                    return pcb

                try:
                    r = docx_processor.convert_docx_latex_to_mathtype(
                        input_path=temp_sk_path,
                        output_path=out_path,
                        use_libreoffice=self.use_libreoffice,
                        progress_callback=make_pcb(base_pct),
                        lo_threads=self.lo_threads,
                        base_pt=self.base_pt
                    )
                    created_files.append(out_path)
                    log(f"✅ Đã tạo thành công: {os.path.basename(out_path)}")
                except Exception as ex:
                    log(f"⚠️ Lỗi chuyển MathType ({task_label}): {ex}")
                    # Sao lưu bản skeleton nếu gặp sự cố
                    shutil.copy2(temp_sk_path, out_path)
                    created_files.append(out_path)

            prog(100, f"Đã hoàn thành xuất {len(created_files)} file Word!")
            log(f"✨ HOÀN TẤT: {os.path.basename(input_file)}")
            return created_files

        finally:
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception:
                pass

    def convert_raw_latex_text(self,
                              latex_text: str,
                              output_docx_path: str,
                              export_mode: str = 'full',
                              progress_callback: Optional[Callable[[int, str], None]] = None,
                              log_callback: Optional[Callable[[str], None]] = None) -> str:
        """Chuyển đổi trực tiếp từ văn bản LaTeX dán trong giao diện sang file Word MathType."""
        temp_dir = tempfile.mkdtemp(prefix="tex2mt_text_")
        try:
            temp_tex = os.path.join(temp_dir, "input.tex")
            with open(temp_tex, "w", encoding="utf-8") as f:
                f.write(latex_text)
            out_dir = os.path.dirname(os.path.abspath(output_docx_path))
            res = self.convert_file(
                input_file=temp_tex,
                output_dir=out_dir,
                export_mode=export_mode,
                progress_callback=progress_callback,
                log_callback=log_callback
            )
            if res and os.path.exists(res[0]):
                # Đổi tên file về đúng output_docx_path
                if os.path.abspath(res[0]) != os.path.abspath(output_docx_path):
                    shutil.move(res[0], output_docx_path)
                return output_docx_path
            return ""
        finally:
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception:
                pass
